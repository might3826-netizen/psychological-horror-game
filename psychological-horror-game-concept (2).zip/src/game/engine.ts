/* ============================================================
   شهر بی‌قانون — GTA3-style open world engine
   drive / walk / peds / traffic / cops + wanted / missions
   ============================================================ */
import * as THREE from "three";
import { AudioSys } from "./audio";
import { buildCity, WORLD, type CityData } from "./world";

export type Quality = "low" | "high";

export interface HudState {
  health: number; armor: number; money: number; wanted: number;
  weapon: string; ammo: string; inCar: boolean; speed: number;
  clock: string; isNight: boolean; objText: string; timer: number | null;
  markerDist: number; bust: number; missionIdx: number; missionTotal: number;
  kills: number; hasMission: boolean; carHealth: number;
}
export interface SnapPed { x: number; z: number; k: "c" | "p" | "g" }
export interface SnapCar { x: number; z: number; cop: boolean }
export interface Snapshot {
  px: number; pz: number; heading: number; camYaw: number; inCar: boolean;
  marker: { x: number; z: number } | null; job: { x: number; z: number } | null;
  peds: SnapPed[]; cars: SnapCar[];
}
export interface EngineCallbacks {
  onHud(h: HudState): void;
  onToast(msg: string, kind: "info" | "danger" | "success" | "mission"): void;
  onEvent(e: { type: "wasted" | "busted" | "pass" | "fail" | "win"; title: string; sub: string }): void;
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];
function angLerp(a: number, b: number, t: number) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * Math.min(1, t);
}

const WEAPONS = [
  { name: "مشت", dmg: 18, rate: 0.45, range: 2.6, auto: false, sfx: "fist" as const },
  { name: "کلت", dmg: 26, rate: 0.34, range: 48, auto: false, sfx: "pistol" as const },
  { name: "یوزی", dmg: 13, rate: 0.11, range: 36, auto: true, sfx: "uzi" as const },
  { name: "شاتگان", dmg: 70, rate: 0.95, range: 20, auto: false, sfx: "shotgun" as const },
];

interface Ped {
  g: THREE.Group; legL: THREE.Mesh; legR: THREE.Mesh; armL: THREE.Mesh; armR: THREE.Mesh;
  active: boolean; kind: "civ" | "cop" | "gang";
  pos: THREE.Vector3; heading: number; speed: number;
  state: "walk" | "idle" | "flee" | "dead" | "chase" | "guard";
  tx: number; tz: number; timer: number; health: number;
  deadT: number; shootT: number; walkT: number; mission: boolean;
}
interface Car {
  g: THREE.Group; wheels: THREE.Object3D[]; frontL: THREE.Object3D; frontR: THREE.Object3D;
  brakeMat: THREE.MeshStandardMaterial; bodyMat: THREE.MeshStandardMaterial;
  pos: THREE.Vector3; heading: number; speed: number; steerVis: number;
  type: "traffic" | "parked" | "player" | "cop";
  axis: "x" | "z"; road: number; s: number; dir: 1 | -1; cruise: number;
  health: number; dead: boolean; exploded: boolean; hitT: number; smokeT: number; honkT: number;
}
interface Pickup {
  kind: "health" | "armor" | "money" | "pistol" | "uzi" | "shotgun";
  amount: number; pos: THREE.Vector3; mesh: THREE.Group; fixed: boolean; respawn: number;
}
interface MissionRt {
  idx: number; step: number; stage: number; timer: number;
  objText: string; marker: { x: number; z: number; r: number; color: number } | null;
  targets: Ped[]; item: { mesh: THREE.Group; x: number; z: number; taken: boolean } | null;
}

const MISSION_TOTAL = 6;
const MISSION_TITLE = ["شروع کار", "بسته مشکوک", "حذف رقبا", "مسابقه خیابانی", "تاکسی دیوانه", "سرقت نهایی"];
const MISSION_REWARD = [200, 450, 800, 1000, 400, 2500];

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private cb: EngineCallbacks;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private raf = 0;
  private disposed = false;
  paused = false;
  isTouch = false;
  quality: Quality = "high";
  audio = new AudioSys();
  private city!: CityData;

  // lights / env
  private sun!: THREE.DirectionalLight;
  private hemi!: THREE.HemisphereLight;
  private amb!: THREE.AmbientLight;
  private skyDay = new THREE.Color(0x87b5e0);
  private skyNight = new THREE.Color(0x05070f);
  private skyDusk = new THREE.Color(0xd4693c);
  private fogDay = new THREE.Color(0x9db8cc);
  private fogNight = new THREE.Color(0x05070c);
  private clockH = 9.5;
  private isNight = false;

  // player
  private pMesh!: THREE.Group;
  private pLegL!: THREE.Mesh; private pLegR!: THREE.Mesh;
  private pArmL!: THREE.Mesh; private pArmR!: THREE.Mesh;
  private pPos = new THREE.Vector3(-58, 0, -52);
  private pHeading = Math.PI;
  private pWalkT = 0;
  private health = 100; private armor = 0; private money = 150;
  private weaponIdx = 1;
  private ammo = [Infinity, 40, 0, 0];
  private owned = [true, true, false, false];
  private fireT = 0; private firing = false;
  private keys = new Set<string>();
  private moveVec = { x: 0, y: 0 };
  private sprintTouch = false;
  private brakeHeld = false;
  private camYaw = Math.PI;
  private camDist = 7.5;
  private shake = 0;
  private kills = 0;

  // car state
  private cars: Car[] = [];
  private playerCar: Car | null = null;
  private headlight!: THREE.SpotLight;
  private headTarget!: THREE.Object3D;
  private headMat!: THREE.MeshStandardMaterial;
  private flashRed!: THREE.MeshStandardMaterial;
  private flashBlue!: THREE.MeshStandardMaterial;

  // peds / pickups
  private peds: Ped[] = [];
  private pickups: Pickup[] = [];

  // wanted
  private wanted = 0;
  private crimeT = 0;
  private stealT = 0;
  private bustProg = 0;
  private decayT = 0;
  private copCarT = 0;

  // mission
  private missionIdx = 0;
  private mrt: MissionRt | null = null;
  private won = false;
  private jobRing!: THREE.Group;
  private objRing!: THREE.Group;
  private objRingMat!: THREE.MeshBasicMaterial;
  private objArrow!: THREE.Mesh;

  // fx
  private parts!: THREE.Points;
  private pPos2!: Float32Array; private pVel!: Float32Array;
  private pLife!: Float32Array; private pMax!: Float32Array; private pGrav!: Float32Array;
  private pGeo!: THREE.BufferGeometry; private pCol!: Float32Array;
  private pCursor = 0;
  private tracers: { line: THREE.Line; t: number }[] = [];
  private muzzle!: THREE.PointLight;
  private boom!: THREE.PointLight;
  private boomT = 0;

  private hudT = 0;
  private spawnT = 0;
  private overlayLock = false;

  constructor(canvas: HTMLCanvasElement, cb: EngineCallbacks, opts: { isTouch: boolean; quality: Quality }) {
    this.canvas = canvas;
    this.cb = cb;
    this.isTouch = opts.isTouch;
    this.quality = opts.quality;
  }

  /* ================= INIT ================= */
  start() {
    this.audio.init();
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: this.quality === "high", powerPreference: "high-performance" });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(this.quality === "high" ? Math.min(window.devicePixelRatio, 1.5) : 1);
    this.renderer.shadowMap.enabled = this.quality === "high";
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87b5e0);
    this.scene.fog = new THREE.Fog(0x9db8cc, 60, 240);

    this.camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 500);
    this.camera.position.set(-58, 5, -62);

    this.sun = new THREE.DirectionalLight(0xffffff, 2.4);
    this.sun.castShadow = this.quality === "high";
    this.sun.shadow.mapSize.set(1024, 1024);
    this.sun.shadow.camera.left = -60; this.sun.shadow.camera.right = 60;
    this.sun.shadow.camera.top = 60; this.sun.shadow.camera.bottom = -60;
    this.sun.shadow.camera.far = 300;
    this.scene.add(this.sun, this.sun.target);
    this.hemi = new THREE.HemisphereLight(0xbdd3e8, 0x3a3f45, 0.9);
    this.scene.add(this.hemi);
    this.amb = new THREE.AmbientLight(0xffffff, 0.25);
    this.scene.add(this.amb);

    this.city = buildCity(this.scene, this.quality);

    this.headlight = new THREE.SpotLight(0xffeecf, 0, 40, 0.5, 0.5, 1.2);
    this.headTarget = new THREE.Object3D();
    this.scene.add(this.headTarget, this.headlight);
    this.headlight.target = this.headTarget;
    this.headMat = new THREE.MeshStandardMaterial({ color: 0x444434, emissive: 0xffedb8, emissiveIntensity: 0 });
    this.flashRed = new THREE.MeshStandardMaterial({ color: 0x330000, emissive: 0xff0000, emissiveIntensity: 0 });
    this.flashBlue = new THREE.MeshStandardMaterial({ color: 0x000033, emissive: 0x2244ff, emissiveIntensity: 0 });

    this.muzzle = new THREE.PointLight(0xffc36b, 0, 12, 1.8);
    this.scene.add(this.muzzle);
    this.boom = new THREE.PointLight(0xff6a22, 0, 30, 1.6);
    this.scene.add(this.boom);

    this.buildPlayer();
    this.buildPools();
    this.buildPickups();
    this.buildRings();
    this.buildParticles();
    this.buildTracers();

    // parked cars
    for (let i = 0; i < 10; i++) this.spawnParked(true);
    // traffic
    for (let i = 0; i < 9; i++) this.spawnTraffic(true);
    // initial peds
    for (let i = 0; i < 14; i++) this.spawnCiv(true);

    window.addEventListener("resize", this.onResize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    this.canvas.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("mouseup", this.onMouseUp);
    this.canvas.addEventListener("wheel", this.onWheel, { passive: true });
    this.canvas.addEventListener("contextmenu", (e) => e.preventDefault());
    if (this.isTouch) this.bindTouch();

    this.clock.start();
    this.loop();
    setTimeout(() => this.cb.onToast("به حلقه زرد برو تا مأموریت شروع شود", "mission"), 2500);
  }

  /* ================= BUILDERS ================= */
  private mat(color: number, rough = 0.85): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({ color, roughness: rough });
  }

  private buildPerson(shirt: number, pants: number, skin: number) {
    const g = new THREE.Group();
    const legG = new THREE.BoxGeometry(0.2, 0.75, 0.24);
    const pm = this.mat(pants);
    const legL = new THREE.Mesh(legG, pm); legL.position.set(-0.13, 0.375, 0);
    const legR = new THREE.Mesh(legG, pm); legR.position.set(0.13, 0.375, 0);
    legL.geometry = legG.clone(); legL.geometry.translate(0, -0.375, 0); legL.position.y = 0.75;
    legR.geometry = legG.clone(); legR.geometry.translate(0, -0.375, 0); legR.position.y = 0.75;
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.68, 0.36), this.mat(shirt));
    torso.position.y = 1.09;
    const armG = new THREE.BoxGeometry(0.16, 0.62, 0.2);
    const armL = new THREE.Mesh(armG, this.mat(shirt)); armL.geometry = armG.clone();
    armL.geometry.translate(0, -0.28, 0); armL.position.set(-0.39, 1.36, 0);
    const armR = new THREE.Mesh(armG, this.mat(shirt)); armR.geometry = armG.clone();
    armR.geometry.translate(0, -0.28, 0); armR.position.set(0.39, 1.36, 0);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.23, 10, 8), this.mat(skin, 0.6));
    head.position.y = 1.68;
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.235, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.45), this.mat(0x1d1410));
    hair.position.y = 1.7;
    g.add(legL, legR, torso, armL, armR, head, hair);
    if (this.quality === "high") g.traverse((o) => { if ((o as THREE.Mesh).isMesh) (o as THREE.Mesh).castShadow = true; });
    return { g, legL, legR, armL, armR };
  }

  private buildPlayer() {
    const p = this.buildPerson(0x3f6b4f, 0x2c3550, 0xc8966e);
    this.pMesh = p.g; this.pLegL = p.legL; this.pLegR = p.legR; this.pArmL = p.armL; this.pArmR = p.armR;
    this.pMesh.position.copy(this.pPos);
    this.scene.add(this.pMesh);
  }

  private buildPools() {
    const shirts = [0x8c4a3c, 0x4a6b8c, 0x8c7a4a, 0x5c4a8c, 0x4a8c5c, 0xb0b0b0, 0x6b4a2e];
    const skins = [0xc8966e, 0x8c5a3c, 0xe0b48c, 0x6b4226];
    for (let i = 0; i < 20; i++) {
      const b = this.buildPerson(pick(shirts), 0x2e3138, pick(skins));
      b.g.visible = false;
      this.scene.add(b.g);
      this.peds.push({ g: b.g, legL: b.legL, legR: b.legR, armL: b.armL, armR: b.armR, active: false, kind: "civ", pos: new THREE.Vector3(), heading: 0, speed: 0, state: "idle", tx: 0, tz: 0, timer: 0, health: 30, deadT: 0, shootT: 0, walkT: rand(0, 6), mission: false });
    }
    for (let i = 0; i < 6; i++) {
      const b = this.buildPerson(0x2a4a9c, 0x1c2440, pick(skins));
      b.g.visible = false;
      this.scene.add(b.g);
      this.peds.push({ g: b.g, legL: b.legL, legR: b.legR, armL: b.armL, armR: b.armR, active: false, kind: "cop", pos: new THREE.Vector3(), heading: 0, speed: 0, state: "idle", tx: 0, tz: 0, timer: 0, health: 70, deadT: 0, shootT: rand(0.5, 1.5), walkT: 0, mission: false });
    }
    for (let i = 0; i < 6; i++) {
      const b = this.buildPerson(0x9c2a2a, 0x242424, pick(skins));
      b.g.visible = false;
      this.scene.add(b.g);
      this.peds.push({ g: b.g, legL: b.legL, legR: b.legR, armL: b.armL, armR: b.armR, active: false, kind: "gang", pos: new THREE.Vector3(), heading: 0, speed: 0, state: "guard", tx: 0, tz: 0, timer: 0, health: 100, deadT: 0, shootT: rand(0.5, 1.5), walkT: 0, mission: false });
    }
  }

  private makeCarMesh(color: number, cop = false, taxi = false) {
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.4, metalness: 0.5 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(2, 0.8, 4.4), bodyMat);
    body.position.y = 0.72;
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.62, 2.1), new THREE.MeshStandardMaterial({ color: 0x141a24, roughness: 0.2, metalness: 0.6 }));
    cabin.position.set(0, 1.4, -0.25);
    g.add(body, cabin);
    const wheelG = new THREE.CylinderGeometry(0.38, 0.38, 0.3, 10);
    wheelG.rotateZ(Math.PI / 2);
    const wheelM = this.mat(0x111111, 1);
    const wheels: THREE.Object3D[] = [];
    const mkWheel = (x: number, z: number) => {
      const pivot = new THREE.Group();
      pivot.position.set(x, 0.38, z);
      const w = new THREE.Mesh(wheelG, wheelM);
      pivot.add(w);
      g.add(pivot);
      wheels.push(pivot);
      return pivot;
    };
    const fL = mkWheel(-0.95, 1.45), fR = mkWheel(0.95, 1.45);
    mkWheel(-0.95, -1.45); mkWheel(0.95, -1.45);
    const head = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.22, 0.12), this.headMat);
    head.position.set(0, 0.75, 2.22);
    g.add(head);
    const brakeMat = new THREE.MeshStandardMaterial({ color: 0x330000, emissive: 0xff0000, emissiveIntensity: 0.25 });
    const brake = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.2, 0.1), brakeMat);
    brake.position.set(0, 0.75, -2.22);
    g.add(brake);
    if (cop) {
      const bar1 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.22, 0.5), this.flashRed);
      bar1.position.set(-0.35, 1.82, -0.25);
      const bar2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.22, 0.5), this.flashBlue);
      bar2.position.set(0.35, 1.82, -0.25);
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.02, 0.3, 4.42), this.mat(0x1c2a4a));
      stripe.position.y = 0.72;
      g.add(bar1, bar2, stripe);
    }
    if (taxi) {
      const sign = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.25, 0.4), new THREE.MeshStandardMaterial({ color: 0x222222, emissive: 0xffcc33, emissiveIntensity: 0.8 }));
      sign.position.set(0, 1.85, -0.25);
      g.add(sign);
    }
    if (this.quality === "high") {
      body.castShadow = true; cabin.castShadow = true;
    }
    return { g, wheels, frontL: fL, frontR: fR, brakeMat, bodyMat };
  }

  private carColors = [0x8c2f2f, 0x2f5f8c, 0x3d3d3d, 0xb0b0b0, 0x2f7a4a, 0x6b4a8c, 0xc0c0c0, 0x8c6a2f, 0x35505c];

  private spawnTraffic(anywhere = false) {
    const taxi = Math.random() < 0.22;
    const m = this.makeCarMesh(taxi ? 0xd8a923 : pick(this.carColors), false, taxi);
    this.scene.add(m.g);
    const rp = anywhere
      ? this.city.roadPointNear(this.pPos.x, this.pPos.z, 40, 120)
      : this.city.roadPointNear(this.pPos.x, this.pPos.z, 60, 110);
    const car: Car = {
      g: m.g, wheels: m.wheels, frontL: m.frontL, frontR: m.frontR, brakeMat: m.brakeMat, bodyMat: m.bodyMat,
      pos: new THREE.Vector3(rp.x, 0, rp.z), heading: rp.axis === "x" ? (rp.dir > 0 ? Math.PI / 2 : -Math.PI / 2) : (rp.dir > 0 ? 0 : Math.PI),
      speed: rand(9, 14), steerVis: 0, type: "traffic",
      axis: rp.axis, road: rp.road, s: rp.axis === "x" ? rp.x : rp.z, dir: rp.dir, cruise: rand(9, 14),
      health: 100, dead: false, exploded: false, hitT: 0, smokeT: 0, honkT: 0,
    };
    this.cars.push(car);
    this.syncCarMesh(car);
    return car;
  }

  private spawnParked(first = false) {
    const m = this.makeCarMesh(pick(this.carColors));
    this.scene.add(m.g);
    const R = WORLD.roads;
    const rc = pick(R);
    const alongX = Math.random() < 0.5;
    const s = first ? rand(-120, 120) : rand(-120, 120);
    const side = (Math.random() < 0.5 ? 1 : -1) * 3.9;
    const x = alongX ? s : rc + side;
    const z = alongX ? rc + side : s;
    const car: Car = {
      g: m.g, wheels: m.wheels, frontL: m.frontL, frontR: m.frontR, brakeMat: m.brakeMat, bodyMat: m.bodyMat,
      pos: new THREE.Vector3(x, 0, z), heading: alongX ? (Math.random() < 0.5 ? Math.PI / 2 : -Math.PI / 2) : (Math.random() < 0.5 ? 0 : Math.PI),
      speed: 0, steerVis: 0, type: "parked",
      axis: "x", road: 0, s: 0, dir: 1, cruise: 0,
      health: 100, dead: false, exploded: false, hitT: 0, smokeT: 0, honkT: 0,
    };
    this.cars.push(car);
    this.syncCarMesh(car);
    return car;
  }

  private spawnCopCar() {
    const m = this.makeCarMesh(0xe8e8e8, true);
    this.scene.add(m.g);
    const rp = this.city.roadPointNear(this.pPos.x, this.pPos.z, 35, 60);
    const car: Car = {
      g: m.g, wheels: m.wheels, frontL: m.frontL, frontR: m.frontR, brakeMat: m.brakeMat, bodyMat: m.bodyMat,
      pos: new THREE.Vector3(rp.x, 0, rp.z), heading: 0, speed: 0, steerVis: 0, type: "cop",
      axis: "x", road: 0, s: 0, dir: 1, cruise: 0,
      health: 120, dead: false, exploded: false, hitT: 0, smokeT: 0, honkT: 0,
    };
    this.cars.push(car);
    this.syncCarMesh(car);
    return car;
  }

  private syncCarMesh(c: Car) {
    c.g.position.copy(c.pos);
    c.g.rotation.y = c.heading;
  }

  private buildPickups() {
    const defs: [Pickup["kind"], number, number, number][] = [
      ["health", 50, -52, -70], ["health", 50, 20, 44], ["health", 50, 88, 20],
      ["armor", 50, -40, -44], ["armor", 50, 44, 66],
      ["uzi", 150, 0, -88], ["shotgun", 24, -88, 88], ["pistol", 60, 88, -88],
    ];
    for (const [kind, amount, x, z] of defs) this.addPickup(kind, amount, x, z, true);
  }

  private addPickup(kind: Pickup["kind"], amount: number, x: number, z: number, fixed: boolean) {
    const g = new THREE.Group();
    if (kind === "health") {
      const m = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xff2222, emissiveIntensity: 0.9 });
      const b1 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.18), m);
      const b2 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.7, 0.18), m);
      const h = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.18, 0.18), m);
      b2.add(h); h.position.y = 0;
      g.add(b1, b2);
    } else if (kind === "armor") {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.55, 0.15), new THREE.MeshStandardMaterial({ color: 0x2244aa, emissive: 0x2244ff, emissiveIntensity: 0.8 }));
      g.add(m);
    } else if (kind === "money") {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.28, 0.08), new THREE.MeshStandardMaterial({ color: 0x2a7a3a, emissive: 0x2aff5a, emissiveIntensity: 0.7 }));
      g.add(m);
    } else {
      const col = kind === "uzi" ? 0x222222 : kind === "shotgun" ? 0x6b4a2e : 0x555555;
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 0.7), new THREE.MeshStandardMaterial({ color: col, emissive: 0xffcc33, emissiveIntensity: 0.35 }));
      g.add(m);
    }
    g.position.set(x, 0.8, z);
    this.scene.add(g);
    this.pickups.push({ kind, amount, pos: new THREE.Vector3(x, 0, z), mesh: g, fixed, respawn: 0 });
  }

  private buildRings() {
    const mkRing = (color: number, r: number) => {
      const g = new THREE.Group();
      const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.75, side: THREE.DoubleSide });
      const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.22, 8, 32), mat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.25;
      const disc = new THREE.Mesh(new THREE.CircleGeometry(r, 28), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.16, side: THREE.DoubleSide }));
      disc.rotation.x = -Math.PI / 2;
      disc.position.y = 0.06;
      g.add(ring, disc);
      return { g, mat };
    };
    const job = mkRing(0xffd23c, 4);
    this.jobRing = job.g;
    this.jobRing.position.set(this.city.plaza.x + 9, 0, this.city.plaza.z + 2);
    this.scene.add(this.jobRing);
    const obj = mkRing(0xffd23c, 5);
    this.objRing = obj.g;
    this.objRingMat = obj.mat;
    this.objArrow = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.6, 4), new THREE.MeshBasicMaterial({ color: 0xffd23c }));
    this.objArrow.rotation.x = Math.PI;
    this.objArrow.position.y = 5;
    this.objRing.add(this.objArrow);
    this.objRing.visible = false;
    this.scene.add(this.objRing);
  }

  private buildParticles() {
    const N = 420;
    this.pPos2 = new Float32Array(N * 3);
    this.pCol = new Float32Array(N * 3);
    this.pVel = new Float32Array(N * 3);
    this.pLife = new Float32Array(N);
    this.pMax = new Float32Array(N);
    this.pGrav = new Float32Array(N);
    for (let i = 0; i < N; i++) this.pPos2[i * 3 + 1] = -50;
    this.pGeo = new THREE.BufferGeometry();
    this.pGeo.setAttribute("position", new THREE.BufferAttribute(this.pPos2, 3));
    this.pGeo.setAttribute("color", new THREE.BufferAttribute(this.pCol, 3));
    const m = new THREE.PointsMaterial({ size: 0.32, vertexColors: true, transparent: true, opacity: 0.95, depthWrite: false });
    this.parts = new THREE.Points(this.pGeo, m);
    this.parts.frustumCulled = false;
    this.scene.add(this.parts);
  }

  private burst(x: number, y: number, z: number, color: THREE.Color, n: number, speed: number, life: number, grav = 9, up = 2) {
    for (let k = 0; k < n; k++) {
      const i = this.pCursor;
      this.pCursor = (this.pCursor + 1) % (this.pLife.length);
      this.pPos2[i * 3] = x; this.pPos2[i * 3 + 1] = y; this.pPos2[i * 3 + 2] = z;
      const a = Math.random() * Math.PI * 2, r = (0.3 + Math.random() * 0.7) * speed;
      this.pVel[i * 3] = Math.cos(a) * r;
      this.pVel[i * 3 + 1] = Math.random() * up + 1;
      this.pVel[i * 3 + 2] = Math.sin(a) * r;
      this.pLife[i] = this.pMax[i] = life * (0.6 + Math.random() * 0.7);
      this.pGrav[i] = grav;
      this.pCol[i * 3] = color.r; this.pCol[i * 3 + 1] = color.g; this.pCol[i * 3 + 2] = color.b;
    }
    (this.pGeo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }

  private buildTracers() {
    for (let i = 0; i < 5; i++) {
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(6), 3));
      const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xffe28a, transparent: true, opacity: 0 }));
      line.frustumCulled = false;
      this.scene.add(line);
      this.tracers.push({ line, t: 0 });
    }
  }

  private tracer(ax: number, ay: number, az: number, bx: number, by: number, bz: number, enemy = false) {
    const t = this.tracers.find((x) => x.t <= 0) || this.tracers[0];
    const attr = t.line.geometry.attributes.position as THREE.BufferAttribute;
    attr.setXYZ(0, ax, ay, az); attr.setXYZ(1, bx, by, bz);
    attr.needsUpdate = true;
    (t.line.material as THREE.LineBasicMaterial).color.setHex(enemy ? 0xff6a6a : 0xffe28a);
    (t.line.material as THREE.LineBasicMaterial).opacity = 1;
    t.t = 0.09;
  }

  /* ================= INPUT ================= */
  private onResize = () => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  };
  private onBlur = () => { this.keys.clear(); this.firing = false; };
  private onKeyDown = (e: KeyboardEvent) => {
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code)) e.preventDefault();
    this.audio.init();
    if (e.repeat) return;
    this.keys.add(e.code);
    if (e.code === "KeyE") this.pressAction();
    if (e.code === "KeyF") this.setFiring(true);
    if (e.code === "KeyH") this.audio.horn();
    if (e.code === "Digit1") this.setWeapon(0);
    if (e.code === "Digit2") this.setWeapon(1);
    if (e.code === "Digit3") this.setWeapon(2);
    if (e.code === "Digit4") this.setWeapon(3);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
    if (e.code === "KeyF") this.setFiring(false);
  };
  private onMouseDown = (e: MouseEvent) => {
    this.audio.init();
    if (e.button === 0 && !this.paused) this.setFiring(true);
  };
  private onMouseUp = () => this.setFiring(false);
  private onWheel = () => { if (!this.paused) this.cycleWeapon(); };

  private lookId: number | null = null;
  private lookX = 0;
  private bindTouch() {
    this.canvas.addEventListener("touchstart", (e) => {
      this.audio.init();
      for (const t of Array.from(e.changedTouches)) {
        if (t.clientX > window.innerWidth * 0.42 && this.lookId === null) {
          this.lookId = t.identifier; this.lookX = t.clientX;
        }
      }
    }, { passive: true });
    this.canvas.addEventListener("touchmove", (e) => {
      if (this.lookId === null || this.paused) return;
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier === this.lookId) {
          this.camYaw -= (t.clientX - this.lookX) * 0.006;
          this.lookX = t.clientX;
        }
      }
    }, { passive: true });
    const end = (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier === this.lookId) this.lookId = null;
      }
    };
    this.canvas.addEventListener("touchend", end);
    this.canvas.addEventListener("touchcancel", end);
  }

  setMove(x: number, y: number) { this.moveVec.x = x; this.moveVec.y = y; }
  setSprint(b: boolean) { this.sprintTouch = b; }
  setBrake(b: boolean) { this.brakeHeld = b; }
  setFiring(b: boolean) {
    const was = this.firing;
    this.firing = b;
    if (b && !was) this.tryFire();
  }

  setWeapon(i: number) {
    if (this.owned[i]) { this.weaponIdx = i; this.audio.uiClick(); }
    else this.cb.onToast("این اسلحه را نداری — در شهر پیدایش کن", "info");
  }
  cycleWeapon() {
    for (let k = 1; k <= 4; k++) {
      const i = (this.weaponIdx + k) % 4;
      if (this.owned[i]) { this.weaponIdx = i; this.audio.uiClick(); return; }
    }
  }

  /* ================= ACTIONS ================= */
  pressAction() {
    if (this.paused || this.overlayLock) return;
    if (this.playerCar) { this.exitCar(); return; }
    let best: Car | null = null; let bd = 4.2;
    for (const c of this.cars) {
      if (c.dead || c.type === "cop") continue;
      if (c.type === "traffic" && Math.abs(c.speed) > 6) continue;
      const d = Math.hypot(c.pos.x - this.pPos.x, c.pos.z - this.pPos.z);
      if (d < bd) { bd = d; best = c; }
    }
    if (best) this.enterCar(best as Car);
  }

  private enterCar(c: Car) {
    this.playerCar = c;
    c.type = "player";
    c.speed = 0;
    this.pMesh.visible = false;
    this.audio.door();
    // witnessed theft?
    if (this.stealT <= 0) {
      const witnessed = this.peds.some((p) => p.active && p.state !== "dead" && Math.hypot(p.pos.x - c.pos.x, p.pos.z - c.pos.z) < 16);
      if (witnessed) {
        this.addWanted(1, "سرقت ماشین دیده شد!");
        this.stealT = 8;
      }
    }
  }

  private exitCar() {
    const c = this.playerCar;
    if (!c) return;
    if (Math.abs(c.speed) > 4) {
      this.cb.onToast("اول سرعت را کم کن!", "info");
      return;
    }
    c.type = "parked";
    c.speed = 0;
    this.playerCar = null;
    const side = c.heading + Math.PI / 2;
    this.pPos.set(c.pos.x + Math.sin(side) * 2.2, 0, c.pos.z + Math.cos(side) * 2.2);
    this.resolveCircle(this.pPos, 0.5);
    this.pHeading = c.heading;
    this.pMesh.visible = true;
    this.audio.door();
  }

  private tryFire() {
    if (this.paused || this.overlayLock || this.fireT > 0) return;
    const w = WEAPONS[this.weaponIdx];
    const ammo = this.ammo[this.weaponIdx];
    if (ammo <= 0) { this.audio.dry(); this.fireT = 0.3; return; }
    const shooter = this.playerCar ? this.playerCar.pos : this.pPos;
    const sy = this.playerCar ? 1.4 : 1.5;
    // auto-aim target
    const fx = Math.sin(this.camYaw), fz = Math.cos(this.camYaw);
    interface Tgt { x: number; y: number; z: number; ped: Ped | null; car: Car | null; d: number }
    const box: { v: Tgt | null } = { v: null };
    const consider = (x: number, y: number, z: number, ped: Ped | null, car: Car | null) => {
      const dx = x - shooter.x, dz = z - shooter.z;
      const d = Math.hypot(dx, dz);
      if (d > w.range) return;
      const dot = (dx * fx + dz * fz) / (d || 1);
      if (d > 10 && dot < 0.45) return;
      if (!box.v || d < box.v.d) box.v = { x, y, z, ped, car, d };
    };
    for (const p of this.peds) {
      if (!p.active || p.state === "dead") continue;
      consider(p.pos.x, 1.2, p.pos.z, p, null);
    }
    for (const c of this.cars) {
      if (c.dead || c === this.playerCar) continue;
      consider(c.pos.x, 1, c.pos.z, null, c);
    }
    this.fireT = w.rate;
    if (this.weaponIdx > 0) this.ammo[this.weaponIdx]--;

    if (w.sfx === "fist") {
      this.audio.fist();
      const t = box.v;
      if (t && t.d < w.range + 0.6) {
        this.pHeading = Math.atan2(t.x - shooter.x, t.z - shooter.z);
        if (t.ped) this.damagePed(t.ped, w.dmg, true);
        this.burst(t.x, 1.2, t.z, new THREE.Color(1, 0.2, 0.2), 4, 2, 0.4);
      }
      return;
    }
    const sfx = w.sfx === "pistol" ? "pistol" : w.sfx === "uzi" ? "uzi" : "shotgun";
    this.audio.shot(sfx);
    this.muzzle.position.set(shooter.x, sy + 0.3, shooter.z);
    this.muzzle.intensity = 6;
    const t = box.v;
    if (t) {
      this.pHeading = Math.atan2(t.x - shooter.x, t.z - shooter.z);
      this.tracer(shooter.x, sy, shooter.z, t.x, t.y, t.z);
      if (t.ped) {
        const fall = w.sfx === "shotgun" ? clamp(1.4 - t.d / w.range, 0.3, 1.2) : 1;
        this.damagePed(t.ped, w.dmg * fall, true);
        this.burst(t.x, t.y, t.z, new THREE.Color(0.8, 0.05, 0.05), 6, 3, 0.5);
      } else if (t.car) {
        this.damageCar(t.car, w.sfx === "shotgun" ? 26 : w.sfx === "uzi" ? 3 : 5, true);
        this.burst(t.x, t.y, t.z, new THREE.Color(1, 0.8, 0.3), 5, 4, 0.35);
      }
    } else {
      const ex = shooter.x + fx * 20, ez = shooter.z + fz * 20;
      this.tracer(shooter.x, sy, shooter.z, ex, 0.2, ez);
      this.burst(ex, 0.2, ez, new THREE.Color(1, 0.85, 0.4), 3, 2, 0.3);
    }
    // gunshot crime
    if (this.crimeT <= 0) {
      const copNear = this.peds.some((p) => p.active && p.kind === "cop" && p.state !== "dead" && Math.hypot(p.pos.x - shooter.x, p.pos.z - shooter.z) < 40);
      const witNear = this.peds.some((p) => p.active && p.kind === "civ" && p.state !== "dead" && Math.hypot(p.pos.x - shooter.x, p.pos.z - shooter.z) < 14);
      if (copNear || witNear) {
        this.addWanted(1, "تیراندازی گزارش شد!");
        this.crimeT = 6;
      }
      // scare peds
      for (const p of this.peds) {
        if (p.active && p.kind === "civ" && p.state !== "dead" && Math.hypot(p.pos.x - shooter.x, p.pos.z - shooter.z) < 22) {
          p.state = "flee"; p.timer = 6;
          p.tx = p.pos.x + (p.pos.x - shooter.x); p.tz = p.pos.z + (p.pos.z - shooter.z);
        }
      }
    }
  }

  /* ================= DAMAGE ================= */
  private damagePed(p: Ped, dmg: number, byPlayer: boolean) {
    if (p.state === "dead") return;
    p.health -= dmg;
    if (p.kind === "civ" && p.state !== "flee") { p.state = "flee"; p.timer = 7; p.tx = p.pos.x + rand(-20, 20); p.tz = p.pos.z + rand(-20, 20); }
    if (p.health <= 0) this.killPed(p, byPlayer);
  }

  private killPed(p: Ped, byPlayer: boolean) {
    p.state = "dead"; p.deadT = 0; p.health = 0;
    this.burst(p.pos.x, 1, p.pos.z, new THREE.Color(0.7, 0.04, 0.04), 14, 3.5, 0.7);
    if (!byPlayer) return;
    this.kills++;
    if (p.kind === "cop") {
      this.addWanted(2, "یک پلیس را کشتی!");
    } else if (p.kind === "civ") {
      this.addWanted(1, "");
      if (Math.random() < 0.4) this.addPickup("money", Math.floor(rand(20, 90)), p.pos.x + rand(-1, 1), p.pos.z + rand(-1, 1), false);
    } else {
      if (Math.random() < 0.6) this.addPickup("money", Math.floor(rand(40, 120)), p.pos.x, p.pos.z, false);
      this.audio.pickup();
    }
    this.audio.thud();
  }

  private damageCar(c: Car, dmg: number, byPlayer: boolean) {
    if (c.dead) return;
    c.health -= dmg;
    if (c.health <= 0) {
      c.dead = true;
      this.explodeCar(c, byPlayer);
    } else if (c.health < 45 && Math.random() < 0.4) {
      this.burst(c.pos.x, 1.2, c.pos.z, new THREE.Color(0.25, 0.25, 0.25), 3, 1.5, 1.1, -1);
    }
  }

  private explodeCar(c: Car, byPlayer: boolean) {
    if (c.exploded) return;
    c.exploded = true;
    this.audio.explosion();
    this.boom.position.set(c.pos.x, 2, c.pos.z);
    this.boomT = 0.5;
    this.burst(c.pos.x, 1, c.pos.z, new THREE.Color(1, 0.5, 0.1), 30, 9, 0.9);
    this.burst(c.pos.x, 1, c.pos.z, new THREE.Color(0.2, 0.2, 0.2), 20, 4, 1.8, -1.5);
    this.shake = Math.min(1.4, this.shake + 0.9);
    c.bodyMat.color.setHex(0x151515);
    c.bodyMat.metalness = 0;
    // area damage
    for (const p of this.peds) {
      if (!p.active || p.state === "dead") continue;
      const d = Math.hypot(p.pos.x - c.pos.x, p.pos.z - c.pos.z);
      if (d < 7) this.killPed(p, byPlayer);
    }
    const pd = Math.hypot(this.pPos.x - c.pos.x, this.pPos.z - c.pos.z);
    if (pd < 8 && !this.playerCar) this.damagePlayer(Math.round(60 * (1 - pd / 9)));
    if (this.playerCar === c) {
      this.damagePlayer(35);
      this.playerCar = null;
      this.pMesh.visible = true;
      this.pPos.set(c.pos.x + 2.5, 0, c.pos.z);
      this.resolveCircle(this.pPos, 0.5);
      this.cb.onToast("ماشین منفجر شد! بپر بیرون", "danger");
    }
    // chain other cars
    for (const o of this.cars) {
      if (o === c || o.dead) continue;
      const d = Math.hypot(o.pos.x - c.pos.x, o.pos.z - c.pos.z);
      if (d < 6) this.damageCar(o, 70, byPlayer);
    }
    setTimeout(() => {
      if (this.disposed) return;
      this.scene.remove(c.g);
      this.cars = this.cars.filter((x) => x !== c);
      if (!this.playerCar || true) {
        if (c.type === "player" || c.type === "parked") this.spawnParked();
        else if (c.type === "traffic") this.spawnTraffic();
      }
    }, 9000);
  }

  private damagePlayer(dmg: number) {
    if (this.overlayLock || dmg <= 0) return;
    if (this.armor > 0) {
      const ab = Math.min(this.armor, Math.round(dmg * 0.6));
      this.armor -= ab;
      dmg -= ab;
    }
    this.health -= dmg;
    this.shake = Math.min(1, this.shake + 0.25);
    if (this.health <= 0) {
      this.health = 0;
      this.wasted();
    }
  }

  private addWanted(n: number, msg: string) {
    const before = this.wanted;
    this.wanted = clamp(this.wanted + n, 0, 5);
    if (msg && this.wanted > before) this.cb.onToast(msg, "danger");
    this.decayT = 0;
  }
  private setWanted(n: number) {
    this.wanted = clamp(n, 0, 5);
    this.decayT = 0;
  }

  /* ================= WASTED / BUSTED ================= */
  private wasted() {
    if (this.overlayLock) return;
    this.overlayLock = true;
    this.audio.wasted();
    const lost = Math.floor(this.money * 0.2);
    this.money -= lost;
    this.failMission("در بیمارستان به هوش آمدی...");
    this.cb.onEvent({ type: "wasted", title: "WASTED", sub: `نابود شدی — ${lost} دلار خرج بیمارستان شد` });
    setTimeout(() => {
      if (this.disposed) return;
      this.health = 100; this.armor = 0;
      this.setWanted(0);
      this.bustProg = 0;
      if (this.playerCar) { this.playerCar.type = "parked"; this.playerCar = null; }
      this.pPos.set(-40, 0, -38);
      this.pMesh.visible = true;
      this.ammo = [Infinity, Math.max(this.ammo[1], 20), this.ammo[2], this.ammo[3]];
      this.overlayLock = false;
    }, 2600);
  }

  private busted() {
    if (this.overlayLock) return;
    this.overlayLock = true;
    this.audio.busted();
    const fine = Math.min(this.money, 150 + this.wanted * 60);
    this.money -= fine;
    this.failMission("از اداره پلیس آزاد شدی...");
    this.cb.onEvent({ type: "busted", title: "BUSTED", sub: `دستگیر شدی — جریمه ${fine} دلار` });
    setTimeout(() => {
      if (this.disposed) return;
      this.health = 100;
      this.setWanted(0);
      this.bustProg = 0;
      this.owned = [true, true, this.ammo[2] > 0, this.ammo[3] > 0];
      this.weaponIdx = 1;
      if (this.playerCar) { this.playerCar.type = "parked"; this.playerCar = null; }
      this.pPos.set(-52, 0, -30);
      this.pMesh.visible = true;
      this.overlayLock = false;
    }, 2600);
  }

  /* ================= COLLISION ================= */
  private resolveCircle(pos: THREE.Vector3, r: number) {
    for (const c of this.city.colliders) {
      const nx = clamp(pos.x, c.x0, c.x1);
      const nz = clamp(pos.z, c.z0, c.z1);
      const dx = pos.x - nx, dz = pos.z - nz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-6) {
          const d = Math.sqrt(d2);
          pos.x = nx + (dx / d) * r;
          pos.z = nz + (dz / d) * r;
        } else {
          // inside: push along smallest penetration
          const pl = pos.x - c.x0, pr = c.x1 - pos.x, pt = pos.z - c.z0, pb = c.z1 - pos.z;
          const m = Math.min(pl, pr, pt, pb);
          if (m === pl) pos.x = c.x0 - r;
          else if (m === pr) pos.x = c.x1 + r;
          else if (m === pt) pos.z = c.z0 - r;
          else pos.z = c.z1 + r;
        }
      }
    }
    pos.x = clamp(pos.x, -158, 158);
    pos.z = clamp(pos.z, -158, 158);
  }

  private circleHitsBuilding(x: number, z: number, r: number) {
    for (const c of this.city.colliders) {
      const nx = clamp(x, c.x0, c.x1);
      const nz = clamp(z, c.z0, c.z1);
      if ((x - nx) * (x - nx) + (z - nz) * (z - nz) < r * r) return true;
    }
    return false;
  }

  /* ================= MISSIONS ================= */
  private jobPos() {
    return { x: this.jobRing.position.x, z: this.jobRing.position.z };
  }

  private startMission(i: number) {
    this.mrt = { idx: i, step: 0, stage: 0, timer: 0, objText: "", marker: null, targets: [], item: null };
    this.audio.missionStart();
    const brief = [
      "سوار یک ماشین شو و به علامت برو. ساده شروع می‌کنیم.",
      "بسته را از نقطه اول بردار و به نقطه دوم برسان. عجله کن!",
      "سه نفر از رقبا در انبار منتظرند. حذفشان کن، بعد از دست پلیس فرار کن.",
      "۵ چک‌پوینت، یک شهر، یک تایمر. گاز بده!",
      "مسافر را سوار کن و سریع و سالم برسان. انعام با توست.",
      "آخرین کار: نگهبان‌های انبار، کیف پول، تحویل در اسکله. پلیس دنبالت خواهد بود!",
    ];
    this.cb.onEvent({ type: "pass", title: `مأموریت ${i + 1}: ${MISSION_TITLE[i]}`, sub: brief[i] });
    this.jobRing.visible = false;
  }

  private passMission() {
    if (!this.mrt) return;
    const i = this.mrt.idx;
    let reward = MISSION_REWARD[i];
    if (i === 3 && this.mrt.timer > 30) reward += Math.floor((this.mrt.timer - 30) * 8);
    if (i === 4) reward += Math.floor(this.mrt.timer * 4);
    this.money += reward;
    this.audio.pass();
    this.cb.onEvent({ type: "pass", title: `مأموریت ${i + 1} انجام شد!`, sub: `+${reward} دلار — ${MISSION_TITLE[i]}` });
    this.cleanupMission();
    this.missionIdx++;
    if (this.missionIdx >= MISSION_TOTAL && !this.won) {
      this.won = true;
      this.money += 1000;
      setTimeout(() => {
        if (!this.disposed) this.cb.onEvent({ type: "win", title: "رئیس شهر شدی!", sub: "هر ۶ مأموریت انجام شد +۱۰۰۰ دلار جایزه. حالا شهر مال توست" });
      }, 2500);
    } else {
      this.jobRing.visible = true;
    }
  }

  private failMission(reason: string) {
    if (!this.mrt) return;
    this.audio.fail();
    this.cb.onEvent({ type: "fail", title: "مأموریت شکست خورد", sub: reason });
    this.cleanupMission();
    this.jobRing.visible = true;
  }

  private cleanupMission() {
    if (!this.mrt) return;
    for (const t of this.mrt.targets) {
      t.active = false; t.mission = false; t.g.visible = false;
    }
    if (this.mrt.item) {
      this.scene.remove(this.mrt.item.mesh);
      this.mrt.item = null;
    }
    this.mrt = null;
    this.objRing.visible = false;
  }

  private spawnGang(x: number, z: number): Ped | null {
    const p = this.peds.find((q) => q.kind === "gang" && !q.active);
    if (!p) return null;
    p.active = true; p.mission = true; p.state = "guard";
    p.pos.set(x + rand(-4, 4), 0, z + rand(-4, 4));
    this.resolveCircle(p.pos, 0.5);
    p.health = 100; p.shootT = rand(0.6, 1.4); p.g.visible = true;
    p.g.rotation.set(0, rand(0, 6), 0);
    p.tx = p.pos.x; p.tz = p.pos.z;
    return p;
  }

  private spawnItem(x: number, z: number, color: number) {
    const g = new THREE.Group();
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.5, 0.25), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.5 }));
    g.add(b);
    g.position.set(x, 0.9, z);
    this.scene.add(g);
    if (this.mrt) this.mrt.item = { mesh: g, x, z, taken: false };
  }

  private updateMission(dt: number) {
    // start trigger
    if (!this.mrt && !this.overlayLock && this.missionIdx < MISSION_TOTAL) {
      const j = this.jobPos();
      const d = Math.hypot(this.pPos.x - j.x, this.pPos.z - j.z);
      if (d < 5) this.startMission(this.missionIdx);
    }
    if (!this.mrt) {
      this.objRing.visible = false;
      return;
    }
    const m = this.mrt;
    const W = this.city.warehouse, D = this.city.docks;
    const setMarker = (x: number, z: number, r: number, color: number) => {
      m.marker = { x, z, r, color };
    };

    switch (m.idx) {
      case 0: { // goto
        setMarker(0, -44, 6, 0xffd23c);
        m.objText = "به علامت زرد برو";
        if (Math.hypot(this.pPos.x - 0, this.pPos.z - (-44)) < 6) this.passMission();
        break;
      }
      case 1: { // pickup + deliver timed
        if (m.stage === 0) {
          setMarker(44, 0, 5, 0xffd23c);
          m.objText = "بسته را بردار";
          if (Math.hypot(this.pPos.x - 44, this.pPos.z - 0) < 5) {
            m.stage = 1; m.timer = 100;
            this.audio.pickup();
            this.cb.onToast("بسته را برداشتی! ببرش به مقصد", "success");
          }
        } else {
          setMarker(-44, 88, 6, 0x3aff6e);
          m.timer -= dt;
          m.objText = "بسته را به مقصد برسان!";
          if (Math.hypot(this.pPos.x - (-44), this.pPos.z - 88) < 6) this.passMission();
          else if (m.timer <= 0) this.failMission("دیر رسیدی! مشتری رفت.");
        }
        break;
      }
      case 2: { // kill gang then lose wanted
        if (m.stage === 0) {
          if (m.targets.length === 0) {
            for (let k = 0; k < 3; k++) {
              const g = this.spawnGang(W.x, W.z);
              if (g) m.targets.push(g);
            }
            this.cb.onToast("رقبا در انبارند — حذفشان کن!", "mission");
          }
          setMarker(W.x, W.z, 9, 0xff5a3c);
          const alive = m.targets.filter((t) => t.state !== "dead").length;
          m.objText = `رقبا را حذف کن (${alive} باقی)`;
          if (alive === 0) {
            m.stage = 1;
            this.setWanted(2);
            this.cb.onToast("پلیس دنبالت است! قایم شو تا ستاره‌ها پاک شوند", "danger");
          }
        } else {
          m.marker = null;
          m.objText = "از دست پلیس فرار کن!";
          if (this.wanted === 0) this.passMission();
        }
        break;
      }
      case 3: { // checkpoints
        const pts: [number, number][] = [[0, 0], [88, 0], [88, 88], [0, 88], [-88, 88]];
        if (m.step === 0 && m.timer === 0) {
          m.timer = 150;
          this.cb.onToast("چک‌پوینت‌ها را به ترتیب رد کن!", "mission");
        }
        m.timer -= dt;
        const [cx, cz] = pts[m.step];
        setMarker(cx, cz, 7, 0x3ac8ff);
        m.objText = `چک‌پوینت ${m.step + 1} از ${pts.length}`;
        if (Math.hypot(this.pPos.x - cx, this.pPos.z - cz) < 7) {
          this.audio.checkpoint();
          m.step++;
          if (m.step >= pts.length) this.passMission();
        } else if (m.timer <= 0) this.failMission("زمان تمام شد!");
        break;
      }
      case 4: { // taxi
        if (m.stage === 0) {
          setMarker(0, 44, 6, 0xffd23c);
          m.objText = "مسافر را سوار کن (با ماشین، توقف کامل)";
          const stopped = this.playerCar && Math.abs(this.playerCar.speed) < 2.5;
          if (stopped && Math.hypot(this.pPos.x - 0, this.pPos.z - 44) < 6) {
            m.stage = 1; m.timer = 120;
            this.audio.pickup();
            this.cb.onToast("مسافر سوار شد! ببرش به مقصد", "success");
          }
        } else {
          setMarker(-88, 0, 6, 0x3aff6e);
          m.timer -= dt;
          m.objText = "مسافر را به مقصد برسان!";
          const stopped = this.playerCar && Math.abs(this.playerCar.speed) < 2.5;
          if (stopped && Math.hypot(this.pPos.x - (-88), this.pPos.z - 0) < 6) this.passMission();
          else if (m.timer <= 0) this.failMission("مسافر دیرش شد و پیاده شد!");
        }
        break;
      }
      case 5: { // finale
        if (m.stage === 0) {
          setMarker(W.x, W.z, 10, 0xffd23c);
          m.objText = "به انبار برو";
          if (Math.hypot(this.pPos.x - W.x, this.pPos.z - W.z) < 22) {
            m.stage = 1;
            for (let k = 0; k < 4; k++) {
              const g = this.spawnGang(W.x, W.z);
              if (g) m.targets.push(g);
            }
            this.cb.onToast("نگهبان‌ها مسلح‌اند!", "danger");
          }
        } else if (m.stage === 1) {
          setMarker(W.x, W.z, 9, 0xff5a3c);
          const alive = m.targets.filter((t) => t.state !== "dead").length;
          m.objText = `نگهبان‌ها را حذف کن (${alive} باقی)`;
          if (alive === 0) {
            m.stage = 2;
            this.spawnItem(W.x, W.z, 0xd8a923);
            this.cb.onToast("کیف را بردار! (پیاده)", "mission");
          }
        } else if (m.stage === 2) {
          setMarker(W.x, W.z, 4, 0xd8a923);
          m.objText = "کیف را بردار!";
          if (!this.playerCar && m.item && Math.hypot(this.pPos.x - m.item.x, this.pPos.z - m.item.z) < 3) {
            m.item.taken = true;
            this.scene.remove(m.item.mesh);
            m.item = null;
            m.stage = 3;
            this.setWanted(3);
            this.audio.pickup();
            this.cb.onToast("پلیس دنبالت است! کیف را به اسکله برسان", "danger");
          }
        } else {
          setMarker(D.x, D.z, 7, 0x3aff6e);
          m.objText = "کیف را به اسکله برسان!";
          if (Math.hypot(this.pPos.x - D.x, this.pPos.z - D.z) < 7) this.passMission();
        }
        break;
      }
    }

    // ring visuals
    if (m.marker) {
      this.objRing.visible = true;
      this.objRing.position.set(m.marker.x, 0, m.marker.z);
      this.objRingMat.color.setHex(m.marker.color);
      (this.objArrow.material as THREE.MeshBasicMaterial).color.setHex(m.marker.color);
      const s = m.marker.r / 5;
      this.objRing.scale.set(s, 1, s);
      this.objArrow.position.y = 5 + Math.sin(performance.now() * 0.004) * 0.6;
    } else {
      this.objRing.visible = false;
    }
    if (m.item && !m.item.taken) {
      m.item.mesh.rotation.y += dt * 2;
      m.item.mesh.position.y = 0.9 + Math.sin(performance.now() * 0.005) * 0.15;
    }
  }

  /* ================= SPAWNS ================= */
  private spawnCiv(first = false) {
    const p = this.peds.find((q) => q.kind === "civ" && !q.active);
    if (!p) return;
    const s = this.city.sidePointNear(this.pPos.x, this.pPos.z, first ? 10 : 25, 75);
    p.active = true; p.state = "walk"; p.health = 30;
    p.pos.set(s.x, 0, s.z);
    this.resolveCircle(p.pos, 0.5);
    const t = this.city.sidePointNear(s.x, s.z, 20, 90);
    p.tx = t.x; p.tz = t.z;
    p.g.visible = true;
    p.g.rotation.set(0, 0, 0);
  }

  private spawnCopPed() {
    const p = this.peds.find((q) => q.kind === "cop" && !q.active);
    if (!p) return null;
    const a = Math.random() * Math.PI * 2;
    p.active = true; p.state = "chase"; p.health = 70;
    p.pos.set(this.pPos.x + Math.cos(a) * rand(14, 24), 0, this.pPos.z + Math.sin(a) * rand(14, 24));
    this.resolveCircle(p.pos, 0.5);
    p.g.visible = true;
    p.shootT = rand(0.8, 1.6);
    return p;
  }

  private updateSpawns(dt: number) {
    this.spawnT -= dt;
    if (this.spawnT > 0) return;
    this.spawnT = 1.2;
    // civs
    const civs = this.peds.filter((p) => p.kind === "civ" && p.active && p.state !== "dead").length;
    if (civs < 15) this.spawnCiv();
    // remove far civs
    for (const p of this.peds) {
      if (p.kind !== "civ" || !p.active) continue;
      if (Math.hypot(p.pos.x - this.pPos.x, p.pos.z - this.pPos.z) > 130) {
        p.active = false; p.g.visible = false;
      }
    }
    // traffic reposition
    for (const c of this.cars) {
      if (c.type !== "traffic") continue;
      if (Math.hypot(c.pos.x - this.pPos.x, c.pos.z - this.pPos.z) > 145) {
        const rp = this.city.roadPointNear(this.pPos.x, this.pPos.z, 65, 110);
        c.axis = rp.axis; c.road = rp.road; c.dir = rp.dir;
        c.s = rp.axis === "x" ? rp.x : rp.z;
        c.pos.set(rp.x, 0, rp.z);
      }
    }
    // cop cars by wanted
    const want = this.wanted >= 4 ? 3 : this.wanted >= 2 ? 2 : this.wanted >= 1 ? 1 : 0;
    const active = this.cars.filter((c) => c.type === "cop" && !c.dead);
    for (const c of active) {
      if (Math.hypot(c.pos.x - this.pPos.x, c.pos.z - this.pPos.z) > 160) {
        const rp = this.city.roadPointNear(this.pPos.x, this.pPos.z, 35, 60);
        c.pos.set(rp.x, 0, rp.z);
        c.speed = 10;
      }
    }
    if (active.length < want) this.spawnCopCar();
    if (active.length > want) {
      const extra = active[active.length - 1];
      this.scene.remove(extra.g);
      this.cars = this.cars.filter((x) => x !== extra);
    }
    // cop peds on foot
    const copsWant = !this.playerCar ? Math.min(this.wanted, 6) : 0;
    const copsHave = this.peds.filter((p) => p.kind === "cop" && p.active && p.state !== "dead").length;
    if (copsHave < copsWant) this.spawnCopPed();
    if (copsHave > copsWant) {
      const extra = this.peds.find((p) => p.kind === "cop" && p.active && p.state !== "dead");
      if (extra) { extra.active = false; extra.g.visible = false; }
    }
  }

  /* ================= MAIN LOOP ================= */
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    if (!this.paused && !this.overlayLock) this.update(dt);
    else if (this.paused) this.audio.frame(false, 0, 0, 0);
    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number) {
    const now = performance.now() * 0.001;

    // clock + env
    this.clockH = (this.clockH + (dt * 24) / 480) % 24;
    this.updateEnv();

    this.fireT -= dt;
    if (this.firing && WEAPONS[this.weaponIdx].auto) this.tryFire();
    this.crimeT -= dt; this.stealT -= dt;
    this.muzzle.intensity = Math.max(0, this.muzzle.intensity - dt * 60);
    if (this.boomT > 0) { this.boomT -= dt; this.boom.intensity = this.boomT > 0 ? 8 * this.boomT : 0; }
    this.shake = Math.max(0, this.shake - dt * 2.2);

    // wanted decay
    if (this.wanted > 0) {
      this.decayT += dt;
      const copNear = this.nearestCopDist() < 32;
      if (this.decayT > 22 && !copNear) {
        this.decayT = 0;
        this.wanted--;
        if (this.wanted === 0) this.cb.onToast("پلیس ردت را گم کرد", "success");
      }
    }

    if (this.playerCar) this.updateDriving(dt);
    else this.updateOnFoot(dt);

    this.updateTraffic(dt);
    this.updateCops(dt);
    this.updatePeds(dt);
    this.updatePickups(dt);
    this.updateMission(dt);
    this.updateSpawns(dt);
    this.updateFx(dt, now);
    this.updateCamera(dt);
    this.updateAudioFrame();

    // job ring pulse
    if (this.jobRing.visible) {
      this.jobRing.rotation.y += dt * 0.8;
      const s = 1 + Math.sin(now * 4) * 0.06;
      this.jobRing.scale.set(s, 1, s);
    }

    // hud
    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.12;
      this.pushHud();
    }
  }

  private playerSpeedVis = 0;

  private updateOnFoot(dt: number) {
    this.headlight.intensity = 0;
    let ix = 0, iz = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) iz -= 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) iz += 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) ix -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) ix += 1;
    ix += this.moveVec.x; iz += this.moveVec.y;
    const mag = Math.hypot(ix, iz);
    const sprint = this.keys.has("ShiftLeft") || this.keys.has("ShiftRight") || this.sprintTouch || this.brakeHeld;
    const speed = sprint ? 8.6 : 4.6;
    if (mag > 0.15) {
      const nx = ix / Math.max(1, mag), nz = iz / Math.max(1, mag);
      // camera-relative (screen-right for a camera looking along fwd is (-fz, fx))
      const fx = Math.sin(this.camYaw), fz = Math.cos(this.camYaw);
      const rx = -Math.cos(this.camYaw), rz = Math.sin(this.camYaw);
      const dx = (rx * nx - fx * nz), dz = (rz * nx - fz * nz);
      const targetH = Math.atan2(dx, dz);
      this.pHeading = angLerp(this.pHeading, targetH, dt * 10);
      this.pPos.x += Math.sin(this.pHeading) * speed * dt * Math.min(1, mag);
      this.pPos.z += Math.cos(this.pHeading) * speed * dt * Math.min(1, mag);
      this.resolveCircle(this.pPos, 0.5);
      this.pWalkT += dt * (sprint ? 13 : 9);
      this.playerSpeedVis = speed;
      // follow cam
      this.camYaw = angLerp(this.camYaw, this.pHeading, dt * 1.6);
    } else {
      this.playerSpeedVis = 0;
    }
    // car collision (pushed)
    for (const c of this.cars) {
      if (c.dead) continue;
      const d = Math.hypot(c.pos.x - this.pPos.x, c.pos.z - this.pPos.z);
      if (d < 2 && Math.abs(c.speed) > 3 && c !== this.playerCar) {
        this.damagePlayer(Math.round(8 + Math.abs(c.speed) * 0.8));
        this.audio.thud();
        const a = Math.atan2(this.pPos.x - c.pos.x, this.pPos.z - c.pos.z);
        this.pPos.x += Math.sin(a) * 2; this.pPos.z += Math.cos(a) * 2;
        this.resolveCircle(this.pPos, 0.5);
      }
    }
    // mesh
    this.pMesh.position.copy(this.pPos);
    this.pMesh.rotation.y = this.pHeading;
    const sw = this.playerSpeedVis > 0.1 ? Math.sin(this.pWalkT) * 0.55 : 0;
    this.pLegL.rotation.x = sw; this.pLegR.rotation.x = -sw;
    this.pArmL.rotation.x = -sw * 0.8; this.pArmR.rotation.x = sw * 0.8;

    // busted check
    if (this.wanted > 0 && this.wanted <= 2) {
      let near = false;
      for (const p of this.peds) {
        if (p.kind === "cop" && p.active && p.state !== "dead" && Math.hypot(p.pos.x - this.pPos.x, p.pos.z - this.pPos.z) < 2.4) {
          near = true; break;
        }
      }
      if (near) {
        this.bustProg += dt / 2.2;
        if (this.bustProg >= 1) { this.bustProg = 0; this.busted(); }
      } else this.bustProg = Math.max(0, this.bustProg - dt);
    } else this.bustProg = Math.max(0, this.bustProg - dt * 2);

    // slow heal
    if (this.wanted === 0 && this.health < 100 && this.health > 0) this.health = Math.min(100, this.health + dt * 1.2);
  }

  private skidVis = 0;

  private updateDriving(dt: number) {
    const c = this.playerCar!;
    let throttle = 0, steer = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) throttle += 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) throttle -= 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) steer -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) steer += 1;
    throttle += -this.moveVec.y;
    steer += this.moveVec.x;
    throttle = clamp(throttle, -1, 1); steer = clamp(steer, -1, 1);
    const brake = this.keys.has("Space") || this.brakeHeld;
    const maxSp = c.dead ? 0 : c.health < 45 ? 16 : 34;
    const maxRev = 10;

    if (throttle > 0) c.speed += 15 * throttle * dt;
    else if (throttle < 0) {
      if (c.speed > 1) c.speed -= 26 * dt; // brake
      else c.speed -= 10 * dt; // reverse
    } else {
      c.speed -= Math.sign(c.speed) * Math.min(Math.abs(c.speed), (brake ? 22 : 4) * dt);
    }
    if (brake) c.speed -= Math.sign(c.speed) * Math.min(Math.abs(c.speed), 20 * dt);
    c.speed = clamp(c.speed, -maxRev, maxSp);

    const spdN = clamp(Math.abs(c.speed) / 20, 0, 1);
    c.heading -= steer * (brake ? 2.6 : 1.9) * dt * Math.sign(c.speed) * (0.35 + 0.65 * spdN);
    c.steerVis += (steer * 0.45 - c.steerVis) * Math.min(1, dt * 8);

    const nx = c.pos.x + Math.sin(c.heading) * c.speed * dt;
    const nz = c.pos.z + Math.cos(c.heading) * c.speed * dt;
    const ox = c.pos.x, oz = c.pos.z;
    c.pos.x = nx; c.pos.z = nz;
    const hitB = this.circleHitsBuilding(c.pos.x, c.pos.z, 1.7);
    // car-car collision
    let hitCar: Car | null = null;
    for (const o of this.cars) {
      if (o === c || o.dead) continue;
      if (Math.hypot(o.pos.x - c.pos.x, o.pos.z - c.pos.z) < 3.4) { hitCar = o; break; }
    }
    if (hitB || c.pos.x < -156 || c.pos.x > 156 || c.pos.z < -156 || c.pos.z > 156) {
      const impact = Math.abs(c.speed);
      c.pos.x = ox; c.pos.z = oz;
      c.pos.x = clamp(c.pos.x, -156, 156); c.pos.z = clamp(c.pos.z, -156, 156);
      if (impact > 6) {
        this.audio.crash(clamp(impact / 25, 0.3, 1));
        this.damageCar(c, impact * 0.9, true);
        this.shake = Math.min(1, this.shake + impact * 0.02);
        this.burst(c.pos.x, 1, c.pos.z, new THREE.Color(1, 0.8, 0.3), 8, 4, 0.4);
      }
      c.speed *= -0.25;
    } else if (hitCar) {
      const impact = Math.abs(c.speed - hitCar.speed);
      if (impact > 4 && c.hitT <= 0) {
        c.hitT = 0.8;
        this.audio.crash(clamp(impact / 22, 0.3, 1));
        this.damageCar(c, impact * 0.7, true);
        this.damageCar(hitCar, impact * 0.7, hitCar.type === "cop" ? false : true);
        this.shake = Math.min(1, this.shake + 0.35);
        if (hitCar.type === "cop") this.addWanted(1, "به ماشین پلیس زدی!");
      }
      // push apart
      const a = Math.atan2(c.pos.x - hitCar.pos.x, c.pos.z - hitCar.pos.z);
      c.pos.x += Math.sin(a) * dt * 3; c.pos.z += Math.cos(a) * dt * 3;
      hitCar.pos.x -= Math.sin(a) * dt * 2; hitCar.pos.z -= Math.cos(a) * dt * 2;
      c.speed *= 0.94;
    }
    c.hitT -= dt;

    // run over peds
    if (Math.abs(c.speed) > 4.5) {
      for (const p of this.peds) {
        if (!p.active || p.state === "dead") continue;
        if (Math.hypot(p.pos.x - c.pos.x, p.pos.z - c.pos.z) < 2.1) {
          this.killPed(p, true);
          this.audio.thud();
          c.speed *= 0.96;
        }
      }
    } else if (Math.abs(c.speed) > 1) {
      // gentle bump scares
      for (const p of this.peds) {
        if (!p.active || p.kind !== "civ" || p.state === "dead") continue;
        if (Math.hypot(p.pos.x - c.pos.x, p.pos.z - c.pos.z) < 2.2) {
          p.state = "flee"; p.timer = 5;
          p.tx = p.pos.x + (p.pos.x - c.pos.x) * 3; p.tz = p.pos.z + (p.pos.z - c.pos.z) * 3;
        }
      }
    }

    // smoke when damaged
    if (c.health < 45 && !c.dead) {
      c.smokeT -= dt;
      if (c.smokeT <= 0) {
        c.smokeT = 0.12;
        this.burst(c.pos.x + Math.sin(c.heading) * 1.6, 1.3, c.pos.z + Math.cos(c.heading) * 1.6, new THREE.Color(0.22, 0.22, 0.22), 2, 1, 1.2, -1);
      }
    }

    this.skidVis += (((brake && Math.abs(c.speed) > 8) ? 1 : 0) - this.skidVis) * Math.min(1, dt * 5);
    if (this.skidVis > 0.5 && Math.random() < 0.5) {
      this.burst(c.pos.x, 0.3, c.pos.z, new THREE.Color(0.6, 0.6, 0.6), 2, 1.5, 0.7, -0.5);
    }

    c.brakeMat.emissiveIntensity = throttle < 0 || brake ? 1.6 : 0.25;
    this.syncCarMesh(c);
    for (const w of c.wheels) (w.children[0] as THREE.Mesh).rotation.x += (c.speed / 0.38) * dt;
    c.frontL.rotation.y = -c.steerVis; c.frontR.rotation.y = -c.steerVis;

    // player pos follows car
    this.pPos.set(c.pos.x, 0, c.pos.z);
    this.pHeading = c.heading;
    this.camYaw = angLerp(this.camYaw, c.heading, dt * (Math.abs(c.speed) > 3 ? 2.6 : 1.2));

    // headlight
    if (this.isNight) {
      this.headlight.intensity = 60;
      this.headlight.position.set(c.pos.x, 1.4, c.pos.z);
      this.headTarget.position.set(c.pos.x + Math.sin(c.heading) * 12, 0, c.pos.z + Math.cos(c.heading) * 12);
    } else this.headlight.intensity = 0;
  }

  private updateTraffic(dt: number) {
    for (const c of this.cars) {
      if (c.type !== "traffic" || c.dead) continue;
      // obstacle ahead?
      let want = c.cruise;
      const ax = Math.sin(c.heading), az = Math.cos(c.heading);
      for (const o of this.cars) {
        if (o === c || o.dead) continue;
        const dx = o.pos.x - c.pos.x, dz = o.pos.z - c.pos.z;
        const fwd = dx * ax + dz * az;
        const side = Math.abs(dx * az - dz * ax);
        if (fwd > 0 && fwd < 8 && side < 2.6) { want = 0; break; }
      }
      if (want > 0) {
        for (const p of this.peds) {
          if (!p.active || p.state === "dead") continue;
          const dx = p.pos.x - c.pos.x, dz = p.pos.z - c.pos.z;
          const fwd = dx * ax + dz * az;
          const side = Math.abs(dx * az - dz * ax);
          if (fwd > 0 && fwd < 6 && side < 2.2) { want = 0; break; }
        }
        if (!this.playerCar) {
          const dx = this.pPos.x - c.pos.x, dz = this.pPos.z - c.pos.z;
          const fwd = dx * ax + dz * az;
          const side = Math.abs(dx * az - dz * ax);
          if (fwd > 0 && fwd < 6 && side < 2.2) want = 0;
        }
      }
      c.speed += (want - c.speed) * Math.min(1, dt * (want < c.speed ? 4 : 1.2));
      c.s += c.dir * c.speed * dt;
      const lim = 140;
      if (c.s > lim) c.s = -lim;
      if (c.s < -lim) c.s = lim;
      const lane = c.dir > 0 ? 2.4 : -2.4;
      if (c.axis === "x") { c.pos.x = c.s; c.pos.z = c.road + lane; }
      else { c.pos.x = c.road + lane; c.pos.z = c.s; }
      this.syncCarMesh(c);
      for (const w of c.wheels) (w.children[0] as THREE.Mesh).rotation.x += (c.speed / 0.38) * dt;
      c.brakeMat.emissiveIntensity = want < c.speed - 1 ? 1.4 : 0.25;
      // hit player on foot?
      if (!this.playerCar && Math.abs(c.speed) > 3 && Math.hypot(c.pos.x - this.pPos.x, c.pos.z - this.pPos.z) < 1.9) {
        this.damagePlayer(Math.round(8 + Math.abs(c.speed) * 0.7));
        this.audio.thud();
        const a = Math.atan2(this.pPos.x - c.pos.x, this.pPos.z - c.pos.z);
        this.pPos.x += Math.sin(a) * 2.2; this.pPos.z += Math.cos(a) * 2.2;
        this.resolveCircle(this.pPos, 0.5);
      }
    }
  }

  private nearestCopDist() {
    let best = 999;
    for (const c of this.cars) {
      if (c.type === "cop" && !c.dead) best = Math.min(best, Math.hypot(c.pos.x - this.pPos.x, c.pos.z - this.pPos.z));
    }
    for (const p of this.peds) {
      if (p.kind === "cop" && p.active && p.state !== "dead") best = Math.min(best, Math.hypot(p.pos.x - this.pPos.x, p.pos.z - this.pPos.z));
    }
    return best;
  }

  private updateCops(dt: number) {
    this.copCarT -= dt;
    for (const c of this.cars) {
      if (c.type !== "cop" || c.dead) continue;
      if (this.wanted === 0) {
        c.speed += (0 - c.speed) * Math.min(1, dt * 2);
        this.syncCarMesh(c);
        continue;
      }
      const dx = this.pPos.x - c.pos.x, dz = this.pPos.z - c.pos.z;
      const dist = Math.hypot(dx, dz);
      const targetH = Math.atan2(dx, dz);
      // obstacle probe
      const px = c.pos.x + Math.sin(c.heading) * 7, pz = c.pos.z + Math.cos(c.heading) * 7;
      let steerH = targetH;
      if (this.circleHitsBuilding(px, pz, 2)) {
        const l = this.circleHitsBuilding(c.pos.x + Math.sin(c.heading - 0.6) * 7, c.pos.z + Math.cos(c.heading - 0.6) * 7, 2);
        steerH = c.heading + (l ? 0.9 : -0.9);
      }
      c.heading = angLerp(c.heading, steerH, dt * 3);
      const maxSp = 22 + this.wanted * 2.5;
      const want = dist > 5 ? maxSp : 0;
      c.speed += (want - c.speed) * Math.min(1, dt * 1.6);
      c.pos.x += Math.sin(c.heading) * c.speed * dt;
      c.pos.z += Math.cos(c.heading) * c.speed * dt;
      if (this.circleHitsBuilding(c.pos.x, c.pos.z, 1.7)) {
        c.pos.x -= Math.sin(c.heading) * c.speed * dt;
        c.pos.z -= Math.cos(c.heading) * c.speed * dt;
        if (Math.abs(c.speed) > 8) {
          this.audio.crash(0.5);
          this.damageCar(c, 8, false);
        }
        c.speed *= 0.4;
        c.heading += 0.8 * dt * 10;
      }
      // ram player car
      if (this.playerCar && dist < 3.6 && c.hitT <= 0) {
        c.hitT = 1;
        this.audio.crash(0.8);
        this.damageCar(this.playerCar, 9, false);
        this.shake = Math.min(1, this.shake + 0.4);
      }
      c.hitT -= dt;
      this.syncCarMesh(c);
      for (const w of c.wheels) (w.children[0] as THREE.Mesh).rotation.x += (c.speed / 0.38) * dt;
    }

    // cop peds
    for (const p of this.peds) {
      if (p.kind !== "cop" || !p.active) continue;
      if (p.state === "dead") continue;
      if (this.wanted === 0) { p.active = false; p.g.visible = false; continue; }
      const dx = this.pPos.x - p.pos.x, dz = this.pPos.z - p.pos.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 120) { p.active = false; p.g.visible = false; continue; }
      if (this.wanted >= 3 || this.playerCar) {
        // shoot
        if (dist > 13) {
          p.heading = angLerp(p.heading, Math.atan2(dx, dz), dt * 8);
          p.pos.x += Math.sin(p.heading) * 6.4 * dt;
          p.pos.z += Math.cos(p.heading) * 6.4 * dt;
          this.resolveCircle(p.pos, 0.5);
          p.walkT += dt * 12;
        } else {
          p.heading = angLerp(p.heading, Math.atan2(dx, dz), dt * 8);
        }
        p.shootT -= dt;
        if (p.shootT <= 0 && dist < 26) {
          p.shootT = rand(0.9, 1.6);
          this.audio.shot("enemy");
          this.tracer(p.pos.x, 1.4, p.pos.z, this.pPos.x, 1.2, this.pPos.z, true);
          const hit = Math.random() < clamp(0.65 - dist / 45, 0.1, 0.6);
          if (hit) {
            this.damagePlayer(6);
            this.burst(this.pPos.x, 1.3, this.pPos.z, new THREE.Color(0.8, 0.05, 0.05), 4, 2, 0.4);
          }
        }
      } else {
        // chase to bust
        p.heading = angLerp(p.heading, Math.atan2(dx, dz), dt * 8);
        if (dist > 1.6) {
          p.pos.x += Math.sin(p.heading) * 6.8 * dt;
          p.pos.z += Math.cos(p.heading) * 6.8 * dt;
          this.resolveCircle(p.pos, 0.5);
          p.walkT += dt * 12;
        }
      }
      p.g.position.copy(p.pos);
      p.g.rotation.y = p.heading;
      const sw = Math.sin(p.walkT) * 0.5;
      p.legL.rotation.x = sw; p.legR.rotation.x = -sw;
      p.armL.rotation.x = -sw * 0.7; p.armR.rotation.x = sw * 0.7;
    }
  }

  private updatePeds(dt: number) {
    for (const p of this.peds) {
      if (!p.active || p.kind === "cop") continue;
      if (p.state === "dead") {
        p.deadT += dt;
        p.g.rotation.x = Math.min(Math.PI / 2, p.g.rotation.x + dt * 5);
        if (p.deadT > 9) {
          p.active = false; p.g.visible = false;
          if (p.mission) { p.mission = false; }
        }
        continue;
      }
      if (p.kind === "gang") {
        this.updateGang(p, dt);
        continue;
      }
      // civ
      if (p.state === "flee") {
        p.timer -= dt;
        const dx = p.tx - p.pos.x, dz = p.tz - p.pos.z;
        const d = Math.hypot(dx, dz);
        if (d > 1 && p.timer > 0) {
          p.heading = Math.atan2(dx, dz);
          p.pos.x += Math.sin(p.heading) * 6.5 * dt;
          p.pos.z += Math.cos(p.heading) * 6.5 * dt;
          this.resolveCircle(p.pos, 0.5);
          p.walkT += dt * 13;
        } else {
          p.state = "idle"; p.timer = rand(1, 3);
        }
      } else if (p.state === "walk") {
        const dx = p.tx - p.pos.x, dz = p.tz - p.pos.z;
        const d = Math.hypot(dx, dz);
        if (d < 2) { p.state = "idle"; p.timer = rand(1, 4); }
        else {
          p.heading = angLerp(p.heading, Math.atan2(dx, dz), dt * 5);
          p.pos.x += Math.sin(p.heading) * 1.7 * dt;
          p.pos.z += Math.cos(p.heading) * 1.7 * dt;
          this.resolveCircle(p.pos, 0.5);
          p.walkT += dt * 8;
        }
      } else {
        p.timer -= dt;
        if (p.timer <= 0) {
          const t = this.city.sidePointNear(p.pos.x, p.pos.z, 15, 80);
          p.tx = t.x; p.tz = t.z;
          p.state = "walk";
        }
      }
      // flee from fast player car
      if (this.playerCar && Math.abs(this.playerCar.speed) > 10) {
        const d = Math.hypot(p.pos.x - this.playerCar.pos.x, p.pos.z - this.playerCar.pos.z);
        if (d < 7 && p.state !== "flee") {
          p.state = "flee"; p.timer = 4;
          p.tx = p.pos.x + (p.pos.x - this.playerCar.pos.x) * 2;
          p.tz = p.pos.z + (p.pos.z - this.playerCar.pos.z) * 2;
        }
      }
      p.g.position.copy(p.pos);
      p.g.rotation.y = p.heading;
      const sw = Math.sin(p.walkT) * (p.state === "flee" ? 0.7 : 0.45);
      p.legL.rotation.x = sw; p.legR.rotation.x = -sw;
      p.armL.rotation.x = -sw * 0.7; p.armR.rotation.x = sw * 0.7;
    }
  }

  private updateGang(p: Ped, dt: number) {
    const dx = this.pPos.x - p.pos.x, dz = this.pPos.z - p.pos.z;
    const dist = Math.hypot(dx, dz);
    if (dist < 45) {
      if (dist > 11) {
        p.heading = angLerp(p.heading, Math.atan2(dx, dz), dt * 6);
        p.pos.x += Math.sin(p.heading) * 4.6 * dt;
        p.pos.z += Math.cos(p.heading) * 4.6 * dt;
        this.resolveCircle(p.pos, 0.5);
        p.walkT += dt * 10;
      } else {
        p.heading = angLerp(p.heading, Math.atan2(dx, dz), dt * 8);
      }
      p.shootT -= dt;
      if (p.shootT <= 0 && dist < 24) {
        p.shootT = rand(1, 1.8);
        this.audio.shot("enemy");
        this.tracer(p.pos.x, 1.4, p.pos.z, this.pPos.x, 1.2, this.pPos.z, true);
        if (Math.random() < clamp(0.6 - dist / 50, 0.08, 0.55)) {
          this.damagePlayer(8);
          this.burst(this.pPos.x, 1.3, this.pPos.z, new THREE.Color(0.8, 0.05, 0.05), 4, 2, 0.4);
        }
      }
    } else {
      // guard idle: small patrol
      p.timer -= dt;
      if (p.timer <= 0) {
        p.timer = rand(2, 5);
        p.tx = p.pos.x + rand(-6, 6); p.tz = p.pos.z + rand(-6, 6);
      }
      const gx = p.tx - p.pos.x, gz = p.tz - p.pos.z;
      if (Math.hypot(gx, gz) > 1) {
        p.heading = angLerp(p.heading, Math.atan2(gx, gz), dt * 4);
        p.pos.x += Math.sin(p.heading) * 1.4 * dt;
        p.pos.z += Math.cos(p.heading) * 1.4 * dt;
        this.resolveCircle(p.pos, 0.5);
        p.walkT += dt * 7;
      }
    }
    p.g.position.copy(p.pos);
    p.g.rotation.y = p.heading;
    const sw = Math.sin(p.walkT) * 0.5;
    p.legL.rotation.x = sw; p.legR.rotation.x = -sw;
  }

  private updatePickups(dt: number) {
    const now = performance.now() * 0.001;
    for (const k of this.pickups) {
      if (!k.mesh.visible) {
        if (k.fixed) {
          k.respawn -= dt;
          if (k.respawn <= 0) k.mesh.visible = true;
        }
        continue;
      }
      k.mesh.rotation.y += dt * 2;
      k.mesh.position.y = 0.8 + Math.sin(now * 3 + k.pos.x) * 0.12;
      const d = Math.hypot(k.pos.x - this.pPos.x, k.pos.z - this.pPos.z);
      if (d < 2.6 && !this.playerCar) {
        let took = true;
        if (k.kind === "health") {
          if (this.health >= 100) took = false;
          else { this.health = Math.min(100, this.health + k.amount); this.cb.onToast(`+${k.amount} جان`, "success"); }
        } else if (k.kind === "armor") {
          if (this.armor >= 100) took = false;
          else { this.armor = Math.min(100, this.armor + k.amount); this.cb.onToast(`+${k.amount} جلیقه`, "success"); }
        } else if (k.kind === "money") {
          this.money += k.amount;
          this.cb.onToast(`+${k.amount} دلار`, "success");
        } else {
          const wi = k.kind === "pistol" ? 1 : k.kind === "uzi" ? 2 : 3;
          this.owned[wi] = true;
          this.ammo[wi] += k.amount;
          this.cb.onToast(`${WEAPONS[wi].name} برداشتی!`, "success");
        }
        if (took) {
          this.audio.pickup();
          if (k.kind === "money") this.audio.money();
          if (k.fixed) { k.mesh.visible = false; k.respawn = 40; }
          else { this.scene.remove(k.mesh); this.pickups = this.pickups.filter((x) => x !== k); }
        }
      }
    }
  }

  private updateFx(dt: number, now: number) {
    // particles
    const pos = this.pGeo.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    const N = this.pLife.length;
    for (let i = 0; i < N; i++) {
      if (this.pLife[i] <= 0) continue;
      this.pLife[i] -= dt;
      if (this.pLife[i] <= 0) { arr[i * 3 + 1] = -50; continue; }
      this.pVel[i * 3 + 1] -= this.pGrav[i] * dt;
      arr[i * 3] += this.pVel[i * 3] * dt;
      arr[i * 3 + 1] += this.pVel[i * 3 + 1] * dt;
      arr[i * 3 + 2] += this.pVel[i * 3 + 2] * dt;
      if (arr[i * 3 + 1] < 0.05) { arr[i * 3 + 1] = 0.05; this.pVel[i * 3 + 1] = 0; }
    }
    pos.needsUpdate = true;
    // tracers
    for (const t of this.tracers) {
      if (t.t > 0) {
        t.t -= dt;
        (t.line.material as THREE.LineBasicMaterial).opacity = Math.max(0, t.t / 0.09);
      }
    }
    // cop flashers
    const on = Math.sin(now * 12) > 0;
    const anyCop = this.cars.some((c) => c.type === "cop" && !c.dead);
    this.flashRed.emissiveIntensity = anyCop && on ? 2.5 : 0.1;
    this.flashBlue.emissiveIntensity = anyCop && !on ? 2.5 : 0.1;
  }

  private updateCamera(dt: number) {
    const inCar = !!this.playerCar;
    const target = inCar ? this.playerCar!.pos : this.pPos;
    const dist = inCar ? 10.5 : 7.2;
    const h = inCar ? 4.6 : 3.6;
    this.camDist += (dist - this.camDist) * Math.min(1, dt * 3);
    const fx = Math.sin(this.camYaw), fz = Math.cos(this.camYaw);
    const des = new THREE.Vector3(target.x - fx * this.camDist, h, target.z - fz * this.camDist);
    // keep camera out of buildings (cheap lift)
    if (this.circleHitsBuilding(des.x, des.z, 0.8)) des.y += 2.5;
    this.camera.position.lerp(des, 1 - Math.exp(-dt * 5));
    if (this.shake > 0.01) {
      this.camera.position.x += rand(-1, 1) * this.shake * 0.25;
      this.camera.position.y += rand(-1, 1) * this.shake * 0.2;
    }
    this.camera.lookAt(target.x, 1.6, target.z);
    // sun follows player for shadows
    this.sun.target.position.set(target.x, 0, target.z);
    this.sun.position.set(target.x + this.sunDir.x * 90, this.sunDir.y * 90, target.z + this.sunDir.z * 90);
  }

  private sunDir = new THREE.Vector3(0.5, 0.8, 0.3);

  private updateEnv() {
    const h = this.clockH;
    // sun elevation: peak at 13h
    const ang = ((h - 6) / 12) * Math.PI; // 6h->0, 18h->PI
    const elev = Math.sin(ang);
    const day = clamp(elev * 2 + 0.25, 0, 1);
    const dusk = clamp(1 - Math.abs(elev) * 4, 0, 1) * (h > 5 && h < 20 ? 1 : 0);
    this.isNight = day < 0.25;
    const night = 1 - day;

    const sky = new THREE.Color().lerpColors(this.skyNight, this.skyDay, day);
    sky.lerp(this.skyDusk, dusk * 0.45);
    (this.scene.background as THREE.Color).copy(sky);
    const fog = new THREE.Color().lerpColors(this.fogNight, this.fogDay, day);
    (this.scene.fog as THREE.Fog).color.copy(fog);

    this.sunDir.set(Math.cos(ang) * 0.7, Math.max(0.12, elev), 0.45).normalize();
    this.sun.intensity = 0.25 + day * 2.3;
    this.sun.color.setHex(this.isNight ? 0x8fa8d8 : dusk > 0.4 ? 0xffb37a : 0xffffff);
    this.hemi.intensity = 0.25 + day * 0.7;
    this.amb.intensity = 0.22 + day * 0.1;

    this.city.windowMat.emissiveIntensity = night * 1.3;
    this.city.bulbMat.emissiveIntensity = night * 2.2;
    this.headMat.emissiveIntensity = night > 0.4 ? 1.6 : 0;
  }

  private updateAudioFrame() {
    const inCar = !!this.playerCar;
    const sp = inCar ? clamp(Math.abs(this.playerCar!.speed) / 30, 0, 1) : 0;
    const sir = this.wanted > 0 ? clamp(1.3 - this.nearestCopDist() / 70, 0, 1) : 0;
    this.audio.frame(inCar, sp, this.skidVis, sir);
  }

  private pushHud() {
    const w = WEAPONS[this.weaponIdx];
    const hh = Math.floor(this.clockH);
    const mm = Math.floor((this.clockH - hh) * 60);
    let markerDist = 0;
    if (this.mrt?.marker) markerDist = Math.hypot(this.mrt.marker.x - this.pPos.x, this.mrt.marker.z - this.pPos.z);
    else if (!this.mrt && this.missionIdx < MISSION_TOTAL) {
      const j = this.jobPos();
      markerDist = Math.hypot(j.x - this.pPos.x, j.z - this.pPos.z);
    }
    let objText = "شهر آزاد است — خلاف کن، پول دربیار!";
    if (this.mrt) objText = this.mrt.objText;
    else if (this.missionIdx < MISSION_TOTAL) objText = `مأموریت ${this.missionIdx + 1}: به حلقه زرد برو`;
    else objText = "رئیس شهر! آزاد بگرد و رکورد پول را بشکن";
    this.cb.onHud({
      health: Math.round(this.health), armor: Math.round(this.armor), money: this.money,
      wanted: this.wanted, weapon: w.name,
      ammo: this.weaponIdx === 0 ? "∞" : String(this.ammo[this.weaponIdx]),
      inCar: !!this.playerCar,
      speed: this.playerCar ? Math.round(Math.abs(this.playerCar.speed) * 3.6) : 0,
      clock: `${hh}:${mm < 10 ? "0" + mm : mm}`,
      isNight: this.isNight, objText,
      timer: this.mrt && this.mrt.timer > 0 ? this.mrt.timer : null,
      markerDist: Math.round(markerDist), bust: this.bustProg,
      missionIdx: this.missionIdx, missionTotal: MISSION_TOTAL,
      kills: this.kills, hasMission: !!this.mrt,
      carHealth: this.playerCar ? Math.max(0, Math.round(this.playerCar.health)) : 0,
    });
  }

  getSnapshot(): Snapshot {
    const peds: SnapPed[] = [];
    for (const p of this.peds) {
      if (!p.active || p.state === "dead") continue;
      peds.push({ x: p.pos.x, z: p.pos.z, k: p.kind === "cop" ? "p" : p.kind === "gang" ? "g" : "c" });
    }
    const cars: SnapCar[] = [];
    for (const c of this.cars) {
      if (c.dead || c === this.playerCar) continue;
      cars.push({ x: c.pos.x, z: c.pos.z, cop: c.type === "cop" });
    }
    return {
      px: this.pPos.x, pz: this.pPos.z, heading: this.pHeading, camYaw: this.camYaw,
      inCar: !!this.playerCar,
      marker: this.mrt?.marker ? { x: this.mrt.marker.x, z: this.mrt.marker.z } : null,
      job: !this.mrt && this.missionIdx < MISSION_TOTAL ? this.jobPos() : null,
      peds, cars,
    };
  }

  /* ================= SETTINGS ================= */
  setPaused(p: boolean) { this.paused = p; if (p) this.firing = false; }
  setQuality(q: Quality) {
    this.quality = q;
    this.renderer.setPixelRatio(q === "high" ? Math.min(window.devicePixelRatio, 1.5) : 1);
    this.renderer.shadowMap.enabled = q === "high";
    this.sun.castShadow = q === "high";
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    this.canvas.removeEventListener("mousedown", this.onMouseDown);
    window.removeEventListener("mouseup", this.onMouseUp);
    this.audio.dispose();
    this.scene?.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const m = (mesh as unknown as { material?: THREE.Material | THREE.Material[] }).material;
      if (Array.isArray(m)) m.forEach((x) => x.dispose?.());
      else if (m?.dispose) m.dispose();
    });
    this.renderer?.dispose();
  }
}
