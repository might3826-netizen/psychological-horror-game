/* ============================================================
   Solar System Engine — cinematic procedural 3D solar system
   sun shader / procedural planet textures / moons / rings /
   asteroid belt / comet / nebulas / fly-to camera / labels
   ============================================================ */
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

/* ---------------- data ---------------- */
export interface MoonData {
  name: string; r: number; dist: number; period: number;
  base: [number, number, number]; kind: "rock" | "ice" | "haze"; craters: number;
}
export interface BodyData {
  id: string; nameFa: string; nameEn: string; color: string;
  radius: number; dist: number; tilt: number; rot: number;
  kind: "star" | "earth" | "gas" | "rock" | "ice" | "venus";
  palette?: [number, number, number][];
  bands?: number; spot?: boolean; base?: [number, number, number];
  contrast?: number; craters?: number; cap?: boolean;
  ring?: { inner: number; outer: number; tint: [number, number, number]; gaps: [number, number][]; alpha: number };
  glow?: string; glowStrength?: number;
  moons: MoonData[];
  facts: { label: string; value: string }[];
  desc: string; tags: string[];
}

export const BODIES: BodyData[] = [
  {
    id: "sun", nameFa: "خورشید", nameEn: "Sun", color: "#ffb300",
    radius: 8, dist: 0, tilt: 0.03, rot: 0.02, kind: "star", moons: [],
    facts: [
      { label: "قطر", value: "۱٬۳۹۲٬۷۰۰ کیلومتر" },
      { label: "دمای سطح", value: "۵٬۵۰۵ درجه سانتی‌گراد" },
      { label: "سن", value: "۴٫۶ میلیارد سال" },
      { label: "جرم", value: "۹۹٫۸۶٪ کل منظومه" },
      { label: "نوع", value: "کوتوله زرد (G2V)" },
      { label: "چرخش", value: "۲۵ روز زمینی" },
    ],
    desc: "قلب تپنده منظومه شمسی؛ ستاره‌ای که هر ثانیه ۶۰۰ میلیون تن هیدروژن را به هلیوم تبدیل می‌کند و نورش پس از ۸ دقیقه به زمین می‌رسد.",
    tags: ["ستاره", "منبع نور", "هم‌جوشی هسته‌ای"],
  },
  {
    id: "mercury", nameFa: "عطارد", nameEn: "Mercury", color: "#b5a58f",
    radius: 0.62, dist: 16, tilt: 0.001, rot: 0.05, kind: "rock",
    base: [168, 152, 132], contrast: 0.5, craters: 90, moons: [],
    facts: [
      { label: "قطر", value: "۴٬۸۷۹ کیلومتر" },
      { label: "فاصله از خورشید", value: "۵۷٫۹ میلیون کیلومتر" },
      { label: "یک سال", value: "۸۸ روز زمینی" },
      { label: "یک روز", value: "۵۹ روز زمینی" },
      { label: "دما", value: "۱۸۰- تا ۴۳۰+ درجه" },
      { label: "قمر", value: "بدون قمر" },
    ],
    desc: "نزدیک‌ترین سیاره به خورشید؛ دنیایی پر از دهانه‌های برخوردی با بیشترین اختلاف دمای شب و روز در کل منظومه.",
    tags: ["نزدیک‌ترین به خورشید", "دهانه‌های برخوردی", "بدون جو"],
  },
  {
    id: "venus", nameFa: "زهره", nameEn: "Venus", color: "#e8c47a",
    radius: 1.1, dist: 22, tilt: 0.05, rot: -0.03, kind: "venus",
    moons: [], glow: "#e8c47a", glowStrength: 0.4,
    facts: [
      { label: "قطر", value: "۱۲٬۱۰۴ کیلومتر" },
      { label: "فاصله از خورشید", value: "۱۰۸٫۲ میلیون کیلومتر" },
      { label: "یک سال", value: "۲۲۵ روز زمینی" },
      { label: "یک روز", value: "۲۴۳ روز (وارونه!)" },
      { label: "دما", value: "۴۶۵ درجه سانتی‌گراد" },
      { label: "قمر", value: "بدون قمر" },
    ],
    desc: "داغ‌ترین سیاره منظومه با اثر گلخانه‌ای مهارنشده؛ زیر ابرهای غلیظ اسید سولفوریک، فشار جو آن ۹۲ برابر زمین است.",
    tags: ["داغ‌ترین سیاره", "چرخش وارونه", "ابرهای اسیدی"],
  },
  {
    id: "earth", nameFa: "زمین", nameEn: "Earth", color: "#3fa9f5",
    radius: 1.2, dist: 28, tilt: 0.41, rot: 0.5, kind: "earth",
    moons: [{ name: "ماه", r: 0.32, dist: 2.6, period: 9, base: [178, 178, 182], kind: "rock", craters: 40 }],
    glow: "#3fa9f5", glowStrength: 0.55,
    facts: [
      { label: "قطر", value: "۱۲٬۷۴۲ کیلومتر" },
      { label: "فاصله از خورشید", value: "۱۴۹٫۶ میلیون کیلومتر" },
      { label: "یک سال", value: "۳۶۵٫۲۵ روز" },
      { label: "یک روز", value: "۲۳٫۹ ساعت" },
      { label: "میانگین دما", value: "۱۵ درجه سانتی‌گراد" },
      { label: "قمر", value: "۱ قمر (ماه)" },
    ],
    desc: "تنها خانه شناخته‌شده حیات؛ سیاره‌ای آبی با اقیانوس‌های مایع، میدان مغناطیسی محافظ و تنها یک قمر وفادار.",
    tags: ["خانه ما", "آب مایع", "حیات"],
  },
  {
    id: "mars", nameFa: "مریخ", nameEn: "Mars", color: "#e0633a",
    radius: 0.82, dist: 34, tilt: 0.44, rot: 0.48, kind: "rock",
    base: [196, 96, 58], contrast: 0.55, craters: 45, cap: true,
    moons: [
      { name: "فوبوس", r: 0.14, dist: 1.5, period: 4, base: [140, 120, 110], kind: "rock", craters: 14 },
      { name: "دیموس", r: 0.11, dist: 1.9, period: 6, base: [150, 132, 120], kind: "rock", craters: 10 },
    ],
    facts: [
      { label: "قطر", value: "۶٬۷۷۹ کیلومتر" },
      { label: "فاصله از خورشید", value: "۲۲۷٫۹ میلیون کیلومتر" },
      { label: "یک سال", value: "۶۸۷ روز زمینی" },
      { label: "یک روز", value: "۲۴٫۶ ساعت" },
      { label: "میانگین دما", value: "۶۳- درجه سانتی‌گراد" },
      { label: "قمر", value: "۲ قمر" },
    ],
    desc: "سیاره سرخ؛ میزبان بلندترین کوه منظومه (المپوس، ۲۲ کیلومتر) و بزرگ‌ترین دره آن. مقصد بعدی انسان برای سکونت.",
    tags: ["سیاره سرخ", "المپوس", "هدف مریخ‌نوردها"],
  },
  {
    id: "jupiter", nameFa: "مشتری", nameEn: "Jupiter", color: "#d8a05e",
    radius: 3.1, dist: 48, tilt: 0.05, rot: 1.2, kind: "gas",
    palette: [[216, 178, 132], [188, 142, 102], [232, 206, 170], [170, 118, 84], [226, 192, 150], [150, 104, 76]],
    bands: 9, spot: true,
    moons: [
      { name: "آیو", r: 0.3, dist: 4.6, period: 5, base: [224, 200, 120], kind: "haze", craters: 8 },
      { name: "اروپا", r: 0.28, dist: 5.4, period: 7, base: [214, 222, 230], kind: "ice", craters: 6 },
      { name: "گانیمد", r: 0.42, dist: 6.4, period: 10, base: [170, 158, 148], kind: "rock", craters: 16 },
      { name: "کالیستو", r: 0.38, dist: 7.4, period: 13, base: [140, 128, 118], kind: "rock", craters: 26 },
    ],
    facts: [
      { label: "قطر", value: "۱۳۹٬۸۲۰ کیلومتر" },
      { label: "فاصله از خورشید", value: "۷۷۸٫۵ میلیون کیلومتر" },
      { label: "یک سال", value: "۱۱٫۹ سال زمینی" },
      { label: "یک روز", value: "۹٫۹ ساعت" },
      { label: "میانگین دما", value: "۱۱۰- درجه سانتی‌گراد" },
      { label: "قمر", value: "۹۵ قمر شناخته‌شده" },
    ],
    desc: "غول گازی و پادشاه سیارات؛ لکه سرخ آن طوفانی بزرگ‌تر از زمین است که قرن‌هاست ادامه دارد. گرانشش سپر زمین در برابر دنباله‌دارهاست.",
    tags: ["بزرگ‌ترین سیاره", "لکه سرخ", "۹۵ قمر"],
  },
  {
    id: "saturn", nameFa: "زحل", nameEn: "Saturn", color: "#e3cfa0",
    radius: 2.65, dist: 62, tilt: 0.47, rot: 1.1, kind: "gas",
    palette: [[228, 208, 168], [214, 188, 142], [238, 222, 188], [200, 172, 128], [222, 198, 158]],
    bands: 7,
    ring: { inner: 3.35, outer: 6.1, tint: [216, 196, 160], gaps: [[0.62, 0.68]], alpha: 0.95 },
    moons: [
      { name: "تیتان", r: 0.4, dist: 7.6, period: 11, base: [224, 170, 90], kind: "haze", craters: 0 },
      { name: "انسلادوس", r: 0.24, dist: 8.6, period: 14, base: [228, 236, 244], kind: "ice", craters: 8 },
    ],
    facts: [
      { label: "قطر", value: "۱۱۶٬۴۶۰ کیلومتر" },
      { label: "فاصله از خورشید", value: "۱٬۴۳۴ میلیون کیلومتر" },
      { label: "یک سال", value: "۲۹٫۴ سال زمینی" },
      { label: "یک روز", value: "۱۰٫۷ ساعت" },
      { label: "میانگین دما", value: "۱۴۰- درجه سانتی‌گراد" },
      { label: "قمر", value: "۱۴۶ قمر شناخته‌شده" },
    ],
    desc: "نگین منظومه با حلقه‌های خیره‌کننده یخی؛ چگالی‌اش از آب کمتر است! تیتان، بزرگ‌ترین قمرش، اقیانوس‌های متان مایع دارد.",
    tags: ["حلقه‌های یخی", "سبک‌تر از آب", "تیتان"],
  },
  {
    id: "uranus", nameFa: "اورانوس", nameEn: "Uranus", color: "#8fd8dd",
    radius: 1.8, dist: 76, tilt: 1.71, rot: -0.7, kind: "ice",
    base: [140, 216, 224],
    ring: { inner: 2.35, outer: 3.15, tint: [170, 200, 205], gaps: [], alpha: 0.4 },
    moons: [{ name: "تیتانیا", r: 0.26, dist: 3.9, period: 10, base: [170, 162, 158], kind: "rock", craters: 14 }],
    glow: "#8fd8dd", glowStrength: 0.35,
    facts: [
      { label: "قطر", value: "۵۰٬۷۲۴ کیلومتر" },
      { label: "فاصله از خورشید", value: "۲٬۸۷۱ میلیون کیلومتر" },
      { label: "یک سال", value: "۸۴ سال زمینی" },
      { label: "یک روز", value: "۱۷٫۲ ساعت (وارونه)" },
      { label: "میانگین دما", value: "۱۹۵- درجه سانتی‌گراد" },
      { label: "قمر", value: "۲۸ قمر شناخته‌شده" },
    ],
    desc: "غول یخی که به پهلو خوابیده و می‌غلتد! محور چرخش ۹۸ درجه‌ای‌اش آن را به عجیب‌ترین سیاره منظومه تبدیل کرده.",
    tags: ["چرخش به پهلو", "سردترین جو", "متان آبی"],
  },
  {
    id: "neptune", nameFa: "نپتون", nameEn: "Neptune", color: "#4a6ff5",
    radius: 1.75, dist: 88, tilt: 0.49, rot: 0.8, kind: "ice",
    base: [74, 110, 245],
    moons: [{ name: "تریتون", r: 0.28, dist: 3.4, period: 9, base: [220, 214, 208], kind: "ice", craters: 10 }],
    glow: "#4a6ff5", glowStrength: 0.4,
    facts: [
      { label: "قطر", value: "۴۹٬۲۴۴ کیلومتر" },
      { label: "فاصله از خورشید", value: "۴٬۴۹۵ میلیون کیلومتر" },
      { label: "یک سال", value: "۱۶۴٫۸ سال زمینی" },
      { label: "یک روز", value: "۱۶٫۱ ساعت" },
      { label: "میانگین دما", value: "۲۰۰- درجه سانتی‌گراد" },
      { label: "قمر", value: "۱۶ قمر شناخته‌شده" },
    ],
    desc: "دورترین سیاره با سریع‌ترین بادهای منظومه (۲٬۱۰۰ کیلومتر بر ساعت)؛ آبی عمیق آن از متان جو می‌آید. با ریاضیات کشف شد، نه تلسکوپ!",
    tags: ["دورترین سیاره", "سریع‌ترین بادها", "کشف با ریاضیات"],
  },
];

/* ---------------- utils ---------------- */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const smoothstep = (a: number, b: number, v: number) => {
  const t = clamp((v - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

function makeNoise2D(seed: number) {
  const rand = mulberry32(seed);
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [p[i], p[j]] = [p[j], p[i]];
  }
  const perm = new Uint8Array(512);
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  const grad = (h: number, x: number, y: number) => {
    switch (h & 3) {
      case 0: return x + y; case 1: return -x + y; case 2: return x - y; default: return -x - y;
    }
  };
  const noise = (x: number, y: number) => {
    const X = Math.floor(x), Y = Math.floor(y);
    const xf = x - X, yf = y - Y;
    const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    const xi = X & 255, yi = Y & 255;
    const aa = perm[perm[xi] + yi], ab = perm[perm[xi] + yi + 1];
    const ba = perm[perm[xi + 1] + yi], bb = perm[perm[xi + 1] + yi + 1];
    return lerp(
      lerp(grad(aa, xf, yf), grad(ba, xf - 1, yf), u),
      lerp(grad(ab, xf, yf - 1), grad(bb, xf - 1, yf - 1), u), v);
  };
  const fbm = (x: number, y: number, oct = 4) => {
    let s = 0, a = 0.5, f = 1, n = 0;
    for (let i = 0; i < oct; i++) { s += a * noise(x * f, y * f); n += a; a *= 0.5; f *= 2.03; }
    return s / n;
  };
  return { noise, fbm };
}

/* ---------------- procedural textures ---------------- */
function canvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D, img: ImageData) => void): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const g = c.getContext("2d")!;
  const img = g.createImageData(w, h);
  draw(g, img);
  g.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.anisotropy = 4;
  return t;
}

function earthTexture(seed: number, w: number, h: number) {
  const { fbm } = makeNoise2D(seed);
  return canvasTex(w, h, (_g, img) => {
    const d = img.data;
    for (let y = 0; y < h; y++) {
      const v = y / h;
      const lat = Math.abs(v - 0.5) * 2;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const cx = Math.cos(th), sx = Math.sin(th);
        const cont = fbm(cx * 1.9 + 11.3, sx * 1.9 + v * 3.8, 5) + 0.28 * fbm(cx * 5.1 + 3.7, sx * 5.1 + v * 9.2, 4);
        const detail = fbm(cx * 9 + 51, sx * 9 + v * 17, 3);
        const i = (y * w + x) * 4;
        let r: number, g: number, b: number;
        if (cont > 0.09) {
          const green = smoothstep(0.09, 0.35, cont);
          const desert = smoothstep(0.55, 0.15, lat) * smoothstep(0.0, 0.25, detail + 0.2);
          r = lerp(lerp(52, 44, green), 196, desert);
          g = lerp(lerp(104, 84, green), 168, desert);
          b = lerp(lerp(46, 52, green), 110, desert);
          const sh = 1 + detail * 0.25;
          r *= sh; g *= sh; b *= sh;
        } else {
          const depth = smoothstep(0.09, -0.35, cont);
          r = lerp(32, 8, depth); g = lerp(92, 32, depth); b = lerp(168, 92, depth);
        }
        const ice = smoothstep(0.78, 0.9, lat + detail * 0.12);
        r = lerp(r, 235, ice); g = lerp(g, 240, ice); b = lerp(b, 245, ice);
        d[i] = clamp(r, 0, 255); d[i + 1] = clamp(g, 0, 255); d[i + 2] = clamp(b, 0, 255); d[i + 3] = 255;
      }
    }
  });
}

function cloudTexture(seed: number, w: number, h: number) {
  const { fbm } = makeNoise2D(seed);
  return canvasTex(w, h, (_g, img) => {
    const d = img.data;
    for (let y = 0; y < h; y++) {
      const v = y / h;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const n = fbm(Math.cos(th) * 3.1 + 7.7, Math.sin(th) * 3.1 + v * 6.2, 5);
        const a = smoothstep(-0.02, 0.32, n + Math.sin(v * 9.0) * 0.04);
        const i = (y * w + x) * 4;
        d[i] = 255; d[i + 1] = 255; d[i + 2] = 255; d[i + 3] = a * 235;
      }
    }
  });
}

function gasTexture(seed: number, w: number, h: number, palette: [number, number, number][], bands: number, spot: boolean, turbAmt: number) {
  const { fbm } = makeNoise2D(seed);
  return canvasTex(w, h, (_g, img) => {
    const d = img.data;
    for (let y = 0; y < h; y++) {
      const v = y / h;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const cx = Math.cos(th), sx = Math.sin(th);
        const turb = fbm(cx * 2.6 + 4.2, sx * 2.6 + v * 7.0, 4);
        const wob = Math.sin(th * 3 + v * 14) * 0.008;
        const bv = v * bands + turb * turbAmt + wob * bands;
        const bi = Math.floor(bv);
        const f = smoothstep(0.25, 0.75, bv - bi);
        const c0 = palette[((bi % palette.length) + palette.length) % palette.length];
        const c1 = palette[(((bi + 1) % palette.length) + palette.length) % palette.length];
        let r = lerp(c0[0], c1[0], f), g = lerp(c0[1], c1[1], f), b = lerp(c0[2], c1[2], f);
        const streak = fbm(cx * 7 + v * 22, sx * 7 + 9.1, 3) * 14;
        r += streak; g += streak; b += streak;
        if (spot) {
          const dx = (x / w - 0.68) * 2.4, dy = (v - 0.63) * 3.1;
          const dd = dx * dx + dy * dy;
          if (dd < 1) {
            const k = smoothstep(1, 0.3, dd);
            r = lerp(r, 205, k * 0.85); g = lerp(g, 110, k * 0.85); b = lerp(b, 80, k * 0.85);
            const ring = smoothstep(0.25, 0.0, Math.abs(dd - 0.55));
            r = lerp(r, 240, ring * 0.4); g = lerp(g, 220, ring * 0.4); b = lerp(b, 200, ring * 0.4);
          }
        }
        const i = (y * w + x) * 4;
        d[i] = clamp(r, 0, 255); d[i + 1] = clamp(g, 0, 255); d[i + 2] = clamp(b, 0, 255); d[i + 3] = 255;
      }
    }
  });
}

function rockTexture(seed: number, w: number, h: number, base: [number, number, number], contrast: number, craterCount: number, cap: boolean) {
  const { fbm } = makeNoise2D(seed);
  const rand = mulberry32(seed * 7 + 1);
  const t = canvasTex(w, h, (_g, img) => {
    const d = img.data;
    for (let y = 0; y < h; y++) {
      const v = y / h;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const n = fbm(Math.cos(th) * 3.4 + 2.9, Math.sin(th) * 3.4 + v * 6.8, 5);
        const n2 = fbm(Math.cos(th) * 9 + 40, Math.sin(th) * 9 + v * 18, 3);
        const m = 1 + n * contrast + n2 * 0.12;
        const i = (y * w + x) * 4;
        let r = base[0] * m, g = base[1] * m, b = base[2] * m;
        if (cap) {
          const lat = Math.abs(v - 0.5) * 2;
          const ice = smoothstep(0.86, 0.96, lat + n2 * 0.1);
          r = lerp(r, 240, ice); g = lerp(g, 238, ice); b = lerp(b, 235, ice);
        }
        d[i] = clamp(r, 0, 255); d[i + 1] = clamp(g, 0, 255); d[i + 2] = clamp(b, 0, 255); d[i + 3] = 255;
      }
    }
  });
  // craters drawn on top (with wrap-around copies)
  const c = t.image as HTMLCanvasElement;
  const g = c.getContext("2d")!;
  for (let k = 0; k < craterCount; k++) {
    const x = rand() * w, y = rand() * h;
    const r = 1.5 + Math.pow(rand(), 2.2) * w * 0.035;
    for (const ox of [0, -w, w]) {
      const grd = g.createRadialGradient(x + ox - r * 0.25, y - r * 0.25, r * 0.1, x + ox, y, r);
      grd.addColorStop(0, "rgba(0,0,0,0.42)");
      grd.addColorStop(0.75, "rgba(0,0,0,0.25)");
      grd.addColorStop(0.92, "rgba(255,255,255,0.20)");
      grd.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = grd;
      g.beginPath(); g.arc(x + ox, y, r, 0, 7); g.fill();
    }
  }
  t.needsUpdate = true;
  return t;
}

function iceTexture(seed: number, w: number, h: number, base: [number, number, number]) {
  const { fbm } = makeNoise2D(seed);
  return canvasTex(w, h, (_g, img) => {
    const d = img.data;
    for (let y = 0; y < h; y++) {
      const v = y / h;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const cx = Math.cos(th), sx = Math.sin(th);
        const band = Math.sin(v * 16 + fbm(cx * 2, sx * 2 + v * 4, 3) * 4) * 0.5 + 0.5;
        const n = fbm(cx * 4 + 8.8, sx * 4 + v * 8, 4);
        const streak = Math.max(0, fbm(cx * 6 + v * 30, sx * 6 + 1.1, 3) - 0.25) * 2;
        const m = 0.88 + band * 0.1 + n * 0.12;
        const i = (y * w + x) * 4;
        d[i] = clamp(base[0] * m + streak * 90, 0, 255);
        d[i + 1] = clamp(base[1] * m + streak * 95, 0, 255);
        d[i + 2] = clamp(base[2] * m + streak * 95, 0, 255);
        d[i + 3] = 255;
      }
    }
  });
}

function venusTexture(seed: number, w: number, h: number) {
  const { fbm } = makeNoise2D(seed);
  return canvasTex(w, h, (_g, img) => {
    const d = img.data;
    for (let y = 0; y < h; y++) {
      const v = y / h;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const cx = Math.cos(th), sx = Math.sin(th);
        const swirl = fbm(cx * 2.2 + v * 5.5 + 3.3, sx * 2.2 - v * 3.0, 4);
        const band = Math.sin(v * 10 + swirl * 5) * 0.5 + 0.5;
        const m = 0.9 + band * 0.12 + swirl * 0.1;
        const i = (y * w + x) * 4;
        d[i] = clamp(232 * m, 0, 255); d[i + 1] = clamp(198 * m, 0, 255);
        d[i + 2] = clamp(142 * m, 0, 255); d[i + 3] = 255;
      }
    }
  });
}

function hazeTexture(seed: number, w: number, h: number, base: [number, number, number]) {
  const { fbm } = makeNoise2D(seed);
  return canvasTex(w, h, (_g, img) => {
    const d = img.data;
    for (let y = 0; y < h; y++) {
      const v = y / h;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const n = fbm(Math.cos(th) * 2.5 + 5.5, Math.sin(th) * 2.5 + v * 5, 4);
        const m = 1 + n * 0.16;
        const i = (y * w + x) * 4;
        d[i] = clamp(base[0] * m, 0, 255); d[i + 1] = clamp(base[1] * m, 0, 255);
        d[i + 2] = clamp(base[2] * m, 0, 255); d[i + 3] = 255;
      }
    }
  });
}

function ringTexture(seed: number, tint: [number, number, number], gaps: [number, number][], alpha: number) {
  const rand = mulberry32(seed);
  const w = 512, h = 8;
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const g = c.getContext("2d")!;
  const img = g.createImageData(w, h);
  const d = img.data;
  const bands: { at: number; w: number; b: number }[] = [];
  for (let i = 0; i < 40; i++) bands.push({ at: rand(), w: 0.004 + rand() * 0.03, b: 0.55 + rand() * 0.45 });
  for (let x = 0; x < w; x++) {
    const u = x / w;
    let a = alpha * (0.35 + 0.65 * Math.sin(u * Math.PI));
    let br = 0;
    for (const bd of bands) {
      const dd = Math.abs(u - bd.at);
      if (dd < bd.w) br = Math.max(br, bd.b * (1 - dd / bd.w));
    }
    for (const [g0, g1] of gaps) {
      if (u > g0 && u < g1) a *= smoothstep(g0, g0 + 0.008, u) * (1 - smoothstep(g1 - 0.008, g1, u)) * 0.06;
    }
    const edge = smoothstep(0, 0.03, u) * (1 - smoothstep(0.97, 1, u));
    a *= edge;
    const m = 0.72 + br * 0.5;
    for (let y = 0; y < h; y++) {
      const i = (y * w + x) * 4;
      d[i] = clamp(tint[0] * m, 0, 255); d[i + 1] = clamp(tint[1] * m, 0, 255);
      d[i + 2] = clamp(tint[2] * m, 0, 255); d[i + 3] = clamp(a * 255, 0, 255);
    }
  }
  g.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function glowTexture(inner: string, outer: string): THREE.CanvasTexture {
  const s = 256;
  const c = document.createElement("canvas");
  c.width = c.height = s;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  grd.addColorStop(0, inner);
  grd.addColorStop(0.25, inner);
  grd.addColorStop(0.6, outer);
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, s, s);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function nebulaTexture(seed: number, hue: number): THREE.CanvasTexture {
  const rand = mulberry32(seed);
  const s = 256;
  const c = document.createElement("canvas");
  c.width = c.height = s;
  const g = c.getContext("2d")!;
  for (let i = 0; i < 60; i++) {
    const x = s / 2 + (rand() - 0.5) * s * 0.7;
    const y = s / 2 + (rand() - 0.5) * s * 0.7;
    const r = 20 + rand() * 60;
    const grd = g.createRadialGradient(x, y, 0, x, y, r);
    const h = hue + (rand() - 0.5) * 40;
    grd.addColorStop(0, `hsla(${h},70%,55%,${0.05 + rand() * 0.06})`);
    grd.addColorStop(1, "hsla(0,0%,0%,0)");
    g.fillStyle = grd;
    g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function tailTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256; c.height = 64;
  const g = c.getContext("2d")!;
  const grd = g.createLinearGradient(0, 0, 256, 0);
  grd.addColorStop(0, "rgba(255,255,255,0.95)");
  grd.addColorStop(0.3, "rgba(180,220,255,0.5)");
  grd.addColorStop(1, "rgba(120,180,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 256, 64);
  // taper vertically
  g.globalCompositeOperation = "destination-in";
  const v = g.createLinearGradient(0, 0, 0, 64);
  v.addColorStop(0, "rgba(0,0,0,0)");
  v.addColorStop(0.5, "rgba(0,0,0,1)");
  v.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = v;
  g.fillRect(0, 0, 256, 64);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/* ---------------- engine ---------------- */
interface RuntimeMoon { data: MoonData; pivot: THREE.Group; mesh: THREE.Mesh; angle: number }
interface RuntimeBody {
  data: BodyData;
  group: THREE.Group;      // positioned on orbit
  tilt: THREE.Group;       // axial tilt
  mesh: THREE.Mesh;
  clouds?: THREE.Mesh;
  angle: number;
  period: number;
  orbitMat: THREE.LineBasicMaterial | null;
  moons: RuntimeMoon[];
  moonGroup: THREE.Group;
  worldPos: THREE.Vector3;
}

export interface SolarCallbacks {
  onSelect(b: BodyData | null): void;
  onStats(days: number): void;
  onReady(): void;
}

const DAYS_PER_SEC = 365.25 / 60;

export class SolarEngine {
  private canvas: HTMLCanvasElement;
  private labelLayer: HTMLElement;
  private cb: SolarCallbacks;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private controls!: OrbitControls;
  private clock = new THREE.Clock();
  private raf = 0;
  private disposed = false;
  private isMobile = false;

  private bodies: RuntimeBody[] = [];
  private clickTargets: THREE.Mesh[] = [];
  private labelEls = new Map<string, HTMLDivElement>();

  private speed = 1.4;
  private paused = false;
  private simDays = 0;
  private sunTime = 0;
  private sunMat!: THREE.ShaderMaterial;

  private selected: RuntimeBody | null = null;
  private following = false;
  private followPrev = new THREE.Vector3();
  private fly: {
    t: number; dur: number;
    fromPos: THREE.Vector3; fromTg: THREE.Vector3;
    toPos: () => THREE.Vector3; toTg: () => THREE.Vector3;
    followAfter: RuntimeBody | null;
  } | null = null;

  private belt!: THREE.Group;
  private kuiper!: THREE.Points;
  private comet!: THREE.Group;
  private cometHead!: THREE.Sprite;
  private cometTail!: THREE.Sprite;
  private cometAngle = 0.6;
  private streaks: { s: THREE.Sprite; vel: THREE.Vector3; life: number; max: number }[] = [];
  private streakT = 3;
  private statT = 0;
  private glowTex!: THREE.CanvasTexture;

  showOrbits = true;
  showBelt = true;
  private showLabels = true;

  constructor(canvas: HTMLCanvasElement, labelLayer: HTMLElement, cb: SolarCallbacks) {
    this.canvas = canvas;
    this.labelLayer = labelLayer;
    this.cb = cb;
    this.isMobile = window.matchMedia("(pointer:coarse)").matches && Math.min(window.innerWidth, window.innerHeight) < 820;
  }

  start() {
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, this.isMobile ? 1.6 : 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 4000);
    this.camera.position.set(0, 300, 470);

    this.controls = new OrbitControls(this.camera, this.canvas);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.minDistance = 1.2;
    this.controls.maxDistance = 600;
    this.controls.addEventListener("start", () => { this.fly = null; });

    this.scene.add(new THREE.AmbientLight(0x8fa3cc, 0.5));
    const sun = new THREE.PointLight(0xfff1dd, 3, 0, 0);
    this.scene.add(sun);

    this.glowTex = glowTexture("rgba(255,255,255,1)", "rgba(255,255,255,0)");

    this.buildSky();
    this.buildBodies();
    this.buildBelt();
    this.buildComet();

    this.camera.lookAt(0, 0, 0);
    // cinematic intro dolly
    this.flyToPoint(new THREE.Vector3(0, 105, 172), new THREE.Vector3(0, 0, 0), 3.2);

    window.addEventListener("resize", this.onResize);
    this.canvas.addEventListener("pointerdown", this.onDown);
    this.canvas.addEventListener("pointerup", this.onUp);

    this.clock.start();
    this.loop();
    requestAnimationFrame(() => this.cb.onReady());
  }

  /* ---------- sky ---------- */
  private buildSky() {
    // gradient dome with milky-way band
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: { uTime: { value: 0 } },
      vertexShader: `
        varying vec3 vDir;
        void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `
        varying vec3 vDir;
        void main(){
          float h = vDir.y * 0.5 + 0.5;
          vec3 col = mix(vec3(0.008,0.010,0.028), vec3(0.020,0.030,0.075), pow(h,1.6));
          float band = exp(-pow(dot(normalize(vDir), normalize(vec3(0.5,0.28,0.82))), 2.0) * 9.0);
          col += vec3(0.045,0.055,0.10) * band;
          float band2 = exp(-pow(dot(normalize(vDir), normalize(vec3(-0.6,0.2,0.75))), 2.0) * 14.0);
          col += vec3(0.05,0.035,0.07) * band2;
          gl_FragColor = vec4(col, 1.0);
        }`,
    });
    this.scene.add(new THREE.Mesh(new THREE.SphereGeometry(1600, 24, 16), skyMat));

    // stars
    const rand = mulberry32(1234);
    const N = this.isMobile ? 1800 : 3600;
    const pos = new Float32Array(N * 3);
    const col = new Float32Array(N * 3);
    const c = new THREE.Color();
    for (let i = 0; i < N; i++) {
      const v = new THREE.Vector3(rand() * 2 - 1, rand() * 2 - 1, rand() * 2 - 1).normalize().multiplyScalar(900 + rand() * 500);
      pos.set([v.x, v.y, v.z], i * 3);
      const r = rand();
      if (r < 0.12) c.setHex(0x9db8ff);
      else if (r < 0.25) c.setHex(0xffd9a8);
      else if (r < 0.32) c.setHex(0xffb3b3);
      else c.setHex(0xffffff);
      c.multiplyScalar(0.55 + rand() * 0.45);
      col.set([c.r, c.g, c.b], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(col, 3));
    this.scene.add(new THREE.Points(g, new THREE.PointsMaterial({
      size: 2.1, sizeAttenuation: false, vertexColors: true,
      transparent: true, opacity: 0.95, depthWrite: false,
    })));

    // bright hero stars with glow
    for (let i = 0; i < 26; i++) {
      const v = new THREE.Vector3(rand() * 2 - 1, rand() * 2 - 1, rand() * 2 - 1).normalize().multiplyScalar(1000);
      const s = new THREE.Sprite(new THREE.SpriteMaterial({
        map: this.glowTex, color: rand() < 0.3 ? 0xbdd2ff : 0xffffff,
        transparent: true, opacity: 0.5 + rand() * 0.4,
        blending: THREE.AdditiveBlending, depthWrite: false,
      }));
      s.position.copy(v);
      const sc = 8 + rand() * 16;
      s.scale.set(sc, sc, 1);
      this.scene.add(s);
    }

    // nebulas
    const nebs: [number, number, THREE.Vector3, number][] = [
      [11, 265, new THREE.Vector3(-550, 180, -650), 620],
      [22, 210, new THREE.Vector3(620, -80, -420), 520],
      [33, 320, new THREE.Vector3(120, 260, -780), 560],
      [44, 180, new THREE.Vector3(-420, -240, 620), 480],
      [55, 25, new THREE.Vector3(560, 160, 560), 420],
    ];
    for (const [seed, hue, p, size] of nebs) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({
        map: nebulaTexture(seed, hue), transparent: true, opacity: 0.5,
        blending: THREE.AdditiveBlending, depthWrite: false,
      }));
      s.position.copy(p);
      s.scale.set(size, size * 0.7, 1);
      this.scene.add(s);
    }
  }

  /* ---------- bodies ---------- */
  private makeGlowSprite(color: string, size: number, opacity: number): THREE.Sprite {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({
      map: this.glowTex, color, transparent: true, opacity,
      blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    s.scale.set(size, size, 1);
    return s;
  }

  private atmosphere(color: string, r: number): THREE.Mesh {
    const m = new THREE.Mesh(
      new THREE.SphereGeometry(r * 1.22, 32, 24),
      new THREE.ShaderMaterial({
        transparent: true, side: THREE.BackSide,
        blending: THREE.AdditiveBlending, depthWrite: false,
        uniforms: { uColor: { value: new THREE.Color(color) } },
        vertexShader: `
          varying vec3 vN; varying vec3 vW;
          void main(){
            vN = normalize(normalMatrix * normal);
            vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz;
            gl_Position = projectionMatrix * viewMatrix * w;
          }`,
        fragmentShader: `
          uniform vec3 uColor; varying vec3 vN; varying vec3 vW;
          void main(){
            vec3 V = normalize(cameraPosition - vW);
            float f = pow(1.0 - abs(dot(normalize(vN), V)), 2.4);
            gl_FragColor = vec4(uColor * f * 1.7, f);
          }`,
      })
    );
    return m;
  }

  private bodyTexture(b: BodyData, seed: number): THREE.CanvasTexture | null {
    const W = this.isMobile ? 256 : 512, H = this.isMobile ? 128 : 256;
    switch (b.kind) {
      case "earth": return earthTexture(seed, W, H);
      case "gas": return gasTexture(seed, W, H, b.palette!, b.bands!, !!b.spot, b.id === "jupiter" ? 1.6 : 0.9);
      case "rock": return rockTexture(seed, W, H, b.base!, b.contrast ?? 0.5, b.craters ?? 40, !!b.cap);
      case "ice": return iceTexture(seed, W, H, b.base!);
      case "venus": return venusTexture(seed, W, H);
      default: return null;
    }
  }

  private moonTexture(m: MoonData, seed: number): THREE.CanvasTexture {
    const W = 128, H = 64;
    if (m.kind === "ice") return iceTexture(seed, W, H, m.base);
    if (m.kind === "haze") return hazeTexture(seed, W, H, m.base);
    return rockTexture(seed, W, H, m.base, 0.45, m.craters, false);
  }

  private buildBodies() {
    const seg = this.isMobile ? 32 : 48;
    BODIES.forEach((data, bi) => {
      const group = new THREE.Group();
      const tilt = new THREE.Group();
      tilt.rotation.z = data.tilt;
      group.add(tilt);

      let mesh: THREE.Mesh;
      if (data.kind === "star") {
        this.sunMat = new THREE.ShaderMaterial({
          uniforms: { uTime: { value: 0 } },
          vertexShader: `
            varying vec3 vN; varying vec3 vP;
            void main(){
              vN = normalize(normalMatrix * normal); vP = position;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
            }`,
          fragmentShader: `
            uniform float uTime; varying vec3 vN; varying vec3 vP;
            float hash(vec3 p){ p = fract(p*0.3183099 + 0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
            float vnoise(vec3 x){
              vec3 i = floor(x); vec3 f = fract(x); f = f*f*(3.0-2.0*f);
              return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),
                             mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
                         mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),
                             mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);
            }
            float fbm(vec3 p){ float s=0.0,a=0.5; for(int i=0;i<4;i++){ s+=a*vnoise(p); p*=2.02; a*=0.5; } return s; }
            void main(){
              vec3 p = normalize(vP);
              float n = fbm(p*3.0 + vec3(0.0,0.0,uTime*0.12));
              float g = fbm(p*9.0 - vec3(uTime*0.25));
              float m = n*0.72 + g*0.28;
              vec3 deep = vec3(0.85,0.22,0.02);
              vec3 mid  = vec3(1.0,0.55,0.08);
              vec3 hot  = vec3(1.0,0.92,0.62);
              vec3 col = mix(deep, mid, smoothstep(0.25,0.55,m));
              col = mix(col, hot, smoothstep(0.55,0.78,m));
              float limb = pow(clamp(dot(normalize(vN), vec3(0.0,0.0,1.0)),0.0,1.0), 0.55);
              col *= (0.55 + 0.45*limb);
              gl_FragColor = vec4(col*1.6, 1.0);
            }`,
        });
        mesh = new THREE.Mesh(new THREE.SphereGeometry(data.radius, seg, seg), this.sunMat);
        // corona layers
        const c1 = this.makeGlowSprite("#ffdd66", 30, 0.85);
        const c2 = this.makeGlowSprite("#ff9a2e", 52, 0.5);
        const c3 = this.makeGlowSprite("#ff5a1e", 95, 0.28);
        group.add(c1, c2, c3);
      } else {
        const tex = this.bodyTexture(data, 100 + bi * 17)!;
        const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 1, metalness: 0 });
        if (data.kind === "rock") { mat.bumpMap = tex; mat.bumpScale = 0.6; }
        mesh = new THREE.Mesh(new THREE.SphereGeometry(data.radius, seg, Math.round(seg * 0.7)), mat);
        if (data.glow) group.add(this.makeGlowSprite(data.glow, data.radius * 4.6, data.glowStrength ?? 0.4));
        if (data.id === "earth") {
          tilt.add(this.atmosphere("#3fa9f5", data.radius));
          const clouds = new THREE.Mesh(
            new THREE.SphereGeometry(data.radius * 1.035, seg, Math.round(seg * 0.7)),
            new THREE.MeshStandardMaterial({ map: cloudTexture(777, this.isMobile ? 256 : 512, this.isMobile ? 128 : 256), transparent: true, depthWrite: false, roughness: 1 })
          );
          tilt.add(clouds);
          const rb = { data, group, tilt, mesh, clouds, angle: 0, period: 0, orbitMat: null, moons: [], moonGroup: new THREE.Group(), worldPos: new THREE.Vector3() };
          tilt.add(mesh);
          group.add(rb.moonGroup);
          this.scene.add(group);
          this.finishBody(rb, data, bi);
          return;
        }
      }
      tilt.add(mesh);
      if (data.ring) {
        const geo = new THREE.RingGeometry(data.ring.inner, data.ring.outer, 128, 1);
        // remap uvs radially
        const posA = geo.attributes.position;
        const uv = geo.attributes.uv;
        const v3 = new THREE.Vector3();
        for (let i = 0; i < posA.count; i++) {
          v3.fromBufferAttribute(posA, i);
          const t = (v3.length() - data.ring.inner) / (data.ring.outer - data.ring.inner);
          uv.setXY(i, t, 0.5);
        }
        const ring = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
          map: ringTexture(500 + bi, data.ring.tint, data.ring.gaps, data.ring.alpha),
          transparent: true, side: THREE.DoubleSide, roughness: 0.9, metalness: 0,
        }));
        ring.rotation.x = -Math.PI / 2;
        tilt.add(ring);
      }
      const rb: RuntimeBody = {
        data, group, tilt, mesh, angle: 0, period: 0,
        orbitMat: null, moons: [], moonGroup: new THREE.Group(), worldPos: new THREE.Vector3(),
      };
      group.add(rb.moonGroup);
      this.scene.add(group);
      this.finishBody(rb, data, bi);
    });
  }

  private finishBody(rb: RuntimeBody, data: BodyData, bi: number) {
    const rand = mulberry32(900 + bi * 31);
    rb.angle = rand() * Math.PI * 2;
    rb.period = data.dist <= 0 ? 0 : 60 * Math.pow(data.dist / 28, 1.5);
    // orbit line
    if (data.dist > 0) {
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 160; i++) {
        const a = (i / 160) * Math.PI * 2;
        pts.push(new THREE.Vector3(Math.cos(a) * data.dist, 0, Math.sin(a) * data.dist));
      }
      const mat = new THREE.LineBasicMaterial({ color: 0x4a6a9e, transparent: true, opacity: 0.35 });
      this.scene.add(new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts), mat));
      rb.orbitMat = mat;
    }
    // moons
    data.moons.forEach((m, mi) => {
      const pivot = new THREE.Group();
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(m.r, 20, 14),
        new THREE.MeshStandardMaterial({ map: this.moonTexture(m, 300 + bi * 50 + mi * 13), roughness: 1 })
      );
      mesh.position.set(m.dist, 0, 0);
      pivot.add(mesh);
      const ringPts: THREE.Vector3[] = [];
      for (let i = 0; i <= 72; i++) {
        const a = (i / 72) * Math.PI * 2;
        ringPts.push(new THREE.Vector3(Math.cos(a) * m.dist, 0, Math.sin(a) * m.dist));
      }
      pivot.add(new THREE.LineLoop(
        new THREE.BufferGeometry().setFromPoints(ringPts),
        new THREE.LineBasicMaterial({ color: 0x5a6a8a, transparent: true, opacity: 0.22 })
      ));
      pivot.rotation.y = rand() * Math.PI * 2;
      rb.moonGroup.add(pivot);
      rb.moons.push({ data: m, pivot, mesh, angle: pivot.rotation.y });
    });
    mesh_userData(rb);
    function mesh_userData(r: RuntimeBody) { r.mesh.userData.bodyId = data.id; }
    this.clickTargets.push(rb.mesh);
    this.bodies.push(rb);
    // label
    const el = document.createElement("div");
    el.className = "sol-label";
    el.innerHTML = `<span class="sol-dot" style="background:${data.color};box-shadow:0 0 8px ${data.color}"></span><span>${data.nameFa}</span>`;
    el.addEventListener("pointerdown", (e) => e.stopPropagation());
    el.addEventListener("click", (e) => { e.stopPropagation(); this.select(data.id, true); });
    this.labelLayer.appendChild(el);
    this.labelEls.set(data.id, el);
    this.placeBody(rb);
  }

  private placeBody(rb: RuntimeBody) {
    if (rb.data.dist > 0) {
      rb.worldPos.set(Math.cos(rb.angle) * rb.data.dist, 0, Math.sin(rb.angle) * rb.data.dist);
      rb.group.position.copy(rb.worldPos);
    } else rb.worldPos.set(0, 0, 0);
  }

  /* ---------- belt / kuiper / comet ---------- */
  private buildBelt() {
    this.belt = new THREE.Group();
    const N = this.isMobile ? 1000 : 2600;
    const rand = mulberry32(4242);
    const inst = new THREE.InstancedMesh(
      new THREE.DodecahedronGeometry(0.32, 0),
      new THREE.MeshStandardMaterial({ roughness: 1 }),
      N
    );
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
    const col = new THREE.Color();
    for (let i = 0; i < N; i++) {
      const a = rand() * Math.PI * 2;
      const r = 39.5 + Math.pow(rand(), 0.7) * 5.5;
      const s = 0.25 + Math.pow(rand(), 2.5) * 1.1;
      q.setFromEuler(e.set(rand() * 6.3, rand() * 6.3, rand() * 6.3));
      m.compose(new THREE.Vector3(Math.cos(a) * r, (rand() - 0.5) * 2.6, Math.sin(a) * r), q, new THREE.Vector3(s, s * (0.6 + rand() * 0.6), s));
      inst.setMatrixAt(i, m);
      col.setHSL(0.07 + rand() * 0.04, 0.25 + rand() * 0.25, 0.28 + rand() * 0.25);
      inst.setColorAt(i, col);
    }
    inst.instanceMatrix.needsUpdate = true;
    if (inst.instanceColor) inst.instanceColor.needsUpdate = true;
    this.belt.add(inst);
    this.scene.add(this.belt);

    // kuiper belt points
    const K = this.isMobile ? 500 : 1000;
    const pos = new Float32Array(K * 3);
    for (let i = 0; i < K; i++) {
      const a = rand() * Math.PI * 2;
      const r = 100 + rand() * 34;
      pos.set([Math.cos(a) * r, (rand() - 0.5) * 12, Math.sin(a) * r], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    this.kuiper = new THREE.Points(g, new THREE.PointsMaterial({
      color: 0x8fa8d8, size: 0.9, transparent: true, opacity: 0.6, depthWrite: false,
    }));
    this.scene.add(this.kuiper);
  }

  private buildComet() {
    this.comet = new THREE.Group();
    this.cometHead = new THREE.Sprite(new THREE.SpriteMaterial({
      map: this.glowTex, color: 0xeaf4ff, transparent: true, opacity: 1,
      blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    this.cometHead.scale.set(3.2, 3.2, 1);
    this.tailTextureAdd();
    this.comet.add(this.cometHead, this.cometTail);
    this.scene.add(this.comet);
  }

  private tailTextureAdd() {
    const mat = new THREE.SpriteMaterial({
      map: tailTexture(), transparent: true, opacity: 0.9,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    this.cometTail = new THREE.Sprite(mat);
    this.cometTail.center.set(0, 0.5);
  }

  /* ---------- selection / camera ---------- */
  select(id: string | null, fly = true) {
    const rb = id ? this.bodies.find((b) => b.data.id === id) ?? null : null;
    if (this.selected?.orbitMat) {
      this.selected.orbitMat.color.setHex(0x4a6a9e);
      this.selected.orbitMat.opacity = 0.35;
    }
    this.selected = rb;
    this.following = false;
    this.labelEls.forEach((el, key) => el.classList.toggle("active", key === id));
    if (rb?.orbitMat) {
      rb.orbitMat.color.set(new THREE.Color(rb.data.color));
      rb.orbitMat.opacity = 0.95;
    }
    if (rb && fly) {
      const dir = this.camera.position.clone().sub(this.controls.target);
      if (dir.lengthSq() < 0.01) dir.set(0.4, 0.5, 1);
      dir.normalize();
      dir.y = Math.max(dir.y, 0.32);
      dir.normalize();
      const off = rb.data.id === "sun" ? 42 : Math.max(rb.data.radius * 5.5, 3.6);
      this.fly = {
        t: 0, dur: 1.7,
        fromPos: this.camera.position.clone(),
        fromTg: this.controls.target.clone(),
        toPos: () => rb.worldPos.clone().addScaledVector(dir, off),
        toTg: () => rb.worldPos.clone(),
        followAfter: rb,
      };
    } else if (!rb) {
      // ease target back to origin, keep camera
      this.fly = {
        t: 0, dur: 1.1,
        fromPos: this.camera.position.clone(),
        fromTg: this.controls.target.clone(),
        toPos: () => this.camera.position.clone(),
        toTg: () => new THREE.Vector3(0, 0, 0),
        followAfter: null,
      };
    }
    this.cb.onSelect(rb ? rb.data : null);
  }

  resetView() {
    if (this.selected?.orbitMat) {
      this.selected.orbitMat.color.setHex(0x4a6a9e);
      this.selected.orbitMat.opacity = 0.35;
    }
    this.selected = null;
    this.following = false;
    this.labelEls.forEach((el) => el.classList.remove("active"));
    this.flyToPoint(new THREE.Vector3(0, 105, 172), new THREE.Vector3(0, 0, 0), 1.8);
    this.cb.onSelect(null);
  }

  private flyToPoint(p: THREE.Vector3, t: THREE.Vector3, dur: number) {
    this.fly = {
      t: 0, dur,
      fromPos: this.camera.position.clone(),
      fromTg: this.controls.target.clone(),
      toPos: () => p.clone(), toTg: () => t.clone(),
      followAfter: null,
    };
  }

  /* ---------- settings ---------- */
  setSpeed(s: number) { this.speed = s; }
  setPaused(p: boolean) { this.paused = p; }
  setOrbits(v: boolean) {
    this.showOrbits = v;
    this.scene.traverse((o) => {
      if ((o as unknown as { isLineLoop?: boolean }).isLineLoop && o.parent === this.scene) o.visible = v;
    });
  }
  setMoons(v: boolean) {
    this.bodies.forEach((b) => { b.moonGroup.visible = v; });
  }
  setBelt(v: boolean) {
    this.showBelt = v;
    this.belt.visible = v;
    this.kuiper.visible = v;
  }
  setLabels(v: boolean) {
    this.showLabels = v;
    this.labelLayer.style.display = v ? "block" : "none";
  }
  setAutoRotate(v: boolean) {
    this.controls.autoRotate = v;
    this.controls.autoRotateSpeed = 0.5;
  }
  capture(): string {
    this.renderer.render(this.scene, this.camera);
    return this.canvas.toDataURL("image/png");
  }

  /* ---------- input ---------- */
  private downPos = { x: 0, y: 0 };
  private onDown = (e: PointerEvent) => { this.downPos = { x: e.clientX, y: e.clientY }; };
  private onUp = (e: PointerEvent) => {
    if (Math.hypot(e.clientX - this.downPos.x, e.clientY - this.downPos.y) > 6) return;
    const r = this.canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((e.clientX - r.left) / r.width) * 2 - 1,
      -((e.clientY - r.top) / r.height) * 2 + 1
    );
    const ray = new THREE.Raycaster();
    ray.setFromCamera(ndc, this.camera);
    const hits = ray.intersectObjects(this.clickTargets, false);
    if (hits.length) this.select(hits[0].object.userData.bodyId as string, true);
    else if (this.selected) this.select(null, true);
  };
  private onResize = () => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  };

  /* ---------- loop ---------- */
  private ease(k: number) { return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2; }

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    const eff = this.paused ? 0 : this.speed;
    const simDt = dt * eff;

    this.sunTime += dt;
    this.sunMat.uniforms.uTime.value = this.sunTime;
    this.simDays += simDt * DAYS_PER_SEC;

    // bodies
    for (const b of this.bodies) {
      if (b.period > 0) {
        b.angle += (simDt / b.period) * Math.PI * 2;
        this.placeBody(b);
      }
      b.mesh.rotation.y += b.data.rot * simDt;
      if (b.clouds) b.clouds.rotation.y += (b.data.rot * 1.35 + 0.01) * simDt;
      for (const m of b.moons) {
        m.pivot.rotation.y += (simDt / m.data.period) * Math.PI * 2;
        m.mesh.rotation.y += simDt * 0.4;
      }
    }

    // belt + kuiper drift
    this.belt.rotation.y += simDt * 0.022;
    this.kuiper.rotation.y += simDt * 0.004;

    // comet on tilted ellipse
    this.cometAngle += (simDt / 110) * Math.PI * 2;
    const ca = this.cometAngle;
    const cometPos = new THREE.Vector3(Math.cos(ca) * 145, 0, Math.sin(ca) * 68);
    cometPos.applyEuler(new THREE.Euler(0.32, 0.5, 0.08));
    this.comet.position.copy(cometPos);
    const sunDist = cometPos.length();
    const vis = clamp(1.25 - sunDist / 110, 0, 1);
    this.comet.visible = vis > 0.02;
    if (this.comet.visible) {
      this.cometHead.material.opacity = vis;
      const away = cometPos.clone().normalize();
      const tailLen = (7 + vis * 26) * (this.isMobile ? 0.8 : 1);
      this.cometTail.scale.set(tailLen, tailLen * 0.22, 1);
      (this.cometTail.material as THREE.SpriteMaterial).opacity = vis * 0.9;
      // orient tail in screen space (texture fades along local +x)
      const p1 = cometPos.clone().project(this.camera);
      const p2 = cometPos.clone().addScaledVector(away, 10).project(this.camera);
      (this.cometTail.material as THREE.SpriteMaterial).rotation =
        Math.atan2(p2.y - p1.y, p2.x - p1.x);
    }

    // shooting stars
    this.streakT -= dt;
    if (this.streakT <= 0) {
      this.streakT = 4 + Math.random() * 9;
      if (this.streaks.length < 3) {
        const s = new THREE.Sprite(new THREE.SpriteMaterial({
          map: this.glowTex, color: 0xcfe4ff, transparent: true, opacity: 0,
          blending: THREE.AdditiveBlending, depthWrite: false,
        }));
        const dir = new THREE.Vector3(Math.random() * 2 - 1, Math.random() * 0.8 + 0.25, Math.random() * 2 - 1).normalize();
        s.position.copy(dir).multiplyScalar(700);
        s.scale.set(46, 2.2, 1);
        const vel = new THREE.Vector3(-dir.z, -0.25 - Math.random() * 0.3, dir.x).normalize().multiplyScalar(420);
        this.scene.add(s);
        this.streaks.push({ s, vel, life: 0, max: 0.9 + Math.random() * 0.5 });
      }
    }
    for (let i = this.streaks.length - 1; i >= 0; i--) {
      const st = this.streaks[i];
      st.life += dt;
      st.s.position.addScaledVector(st.vel, dt);
      const k = st.life / st.max;
      st.s.material.opacity = k < 0.2 ? k / 0.2 : 1 - (k - 0.2) / 0.8;
      const sp1 = st.s.position.clone().project(this.camera);
      const sp2 = st.s.position.clone().addScaledVector(st.vel, 0.05).project(this.camera);
      st.s.material.rotation = Math.atan2(sp2.y - sp1.y, sp2.x - sp1.x);
      if (k >= 1) {
        this.scene.remove(st.s);
        st.s.material.dispose();
        this.streaks.splice(i, 1);
      }
    }

    // camera fly / follow
    if (this.fly) {
      const f = this.fly;
      f.t += dt;
      const k = this.ease(clamp(f.t / f.dur, 0, 1));
      this.camera.position.lerpVectors(f.fromPos, f.toPos(), k);
      this.controls.target.lerpVectors(f.fromTg, f.toTg(), k);
      if (f.t >= f.dur) {
        if (f.followAfter) {
          this.following = true;
          this.followPrev.copy(f.followAfter.worldPos);
        }
        this.fly = null;
      }
    } else if (this.following && this.selected) {
      const delta = this.selected.worldPos.clone().sub(this.followPrev);
      this.camera.position.add(delta);
      this.controls.target.copy(this.selected.worldPos);
      this.followPrev.copy(this.selected.worldPos);
    }
    this.controls.update();

    this.updateLabels();
    this.renderer.render(this.scene, this.camera);

    this.statT += dt;
    if (this.statT > 0.25) {
      this.statT = 0;
      this.cb.onStats(this.simDays);
    }
  };

  private projV = new THREE.Vector3();
  private updateLabels() {
    if (!this.showLabels) return;
    const w = window.innerWidth, h = window.innerHeight;
    const halfFovTan = Math.tan((this.camera.fov * Math.PI) / 360);
    for (const b of this.bodies) {
      const el = this.labelEls.get(b.data.id)!;
      if (this.selected?.data.id === b.data.id) { el.style.display = "none"; continue; }
      this.projV.copy(b.worldPos);
      const camDist = this.camera.position.distanceTo(b.worldPos);
      this.projV.project(this.camera);
      if (this.projV.z > 1 || this.projV.z < -1) { el.style.display = "none"; continue; }
      const x = (this.projV.x * 0.5 + 0.5) * w;
      const y = (-this.projV.y * 0.5 + 0.5) * h;
      if (x < -80 || x > w + 80 || y < -40 || y > h + 40) { el.style.display = "none"; continue; }
      const projR = (b.data.radius / Math.max(camDist, 0.1)) * (h / (2 * halfFovTan));
      el.style.display = "flex";
      el.style.transform = `translate(${x.toFixed(1)}px,${(y - projR - 16).toFixed(1)}px) translate(-50%,-100%)`;
      el.style.opacity = camDist > 420 ? "0.35" : "1";
    }
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    this.canvas.removeEventListener("pointerdown", this.onDown);
    this.canvas.removeEventListener("pointerup", this.onUp);
    this.controls.dispose();
    this.labelLayer.innerHTML = "";
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = (mesh as unknown as { material?: THREE.Material | THREE.Material[] }).material;
      const mats = Array.isArray(mat) ? mat : mat ? [mat] : [];
      mats.forEach((mm) => {
        const withMap = mm as THREE.MeshStandardMaterial;
        if (withMap.map) withMap.map.dispose();
        mm.dispose();
      });
    });
    this.renderer.dispose();
  }
}
