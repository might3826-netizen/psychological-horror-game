/* City generator: ground texture, buildings, lamps, park, plaza, docks */
import * as THREE from "three";

export const WORLD = {
  pitch: 44,
  half: 170,
  ground: 340,
  roads: [-132, -88, -44, 0, 44, 88, 132] as number[],
  roadHalf: 5,
};

export interface Collider { x0: number; x1: number; z0: number; z1: number }
export interface CityData {
  group: THREE.Group;
  colliders: Collider[];
  windowMat: THREE.MeshStandardMaterial;
  bulbMat: THREE.MeshStandardMaterial;
  plaza: { x: number; z: number };
  parkC: { x: number; z: number };
  warehouse: { x: number; z: number };
  docks: { x: number; z: number };
  roadPointNear(x: number, z: number, minD: number, maxD: number): { x: number; z: number; axis: "x" | "z"; dir: 1 | -1; road: number };
  sidePointNear(x: number, z: number, minD: number, maxD: number): { x: number; z: number };
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

function facadeTextures() {
  const map = document.createElement("canvas"); map.width = 128; map.height = 128;
  const g = map.getContext("2d")!;
  g.fillStyle = "#9a9da5"; g.fillRect(0, 0, 128, 128);
  g.fillStyle = "rgba(0,0,0,.18)";
  for (let i = 0; i < 200; i++) g.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
  const emi = document.createElement("canvas"); emi.width = 128; emi.height = 128;
  const e = emi.getContext("2d")!;
  e.fillStyle = "#000"; e.fillRect(0, 0, 128, 128);
  for (let ry = 0; ry < 7; ry++) for (let cx = 0; cx < 5; cx++) {
    const x = 8 + cx * 24, y = 8 + ry * 17;
    g.fillStyle = "#141b28"; g.fillRect(x, y, 15, 11);
    g.fillStyle = "rgba(140,170,210,.35)"; g.fillRect(x, y, 15, 3);
    if (Math.random() < 0.55) {
      e.fillStyle = pick(["#ffca7a", "#ffd9a0", "#ffb35c", "#fff2cc"]);
      e.fillRect(x, y, 15, 11);
    }
  }
  const mapT = new THREE.CanvasTexture(map);
  mapT.colorSpace = THREE.SRGBColorSpace;
  const emiT = new THREE.CanvasTexture(emi);
  emiT.colorSpace = THREE.SRGBColorSpace;
  return { mapT, emiT };
}

function groundTexture(park: Collider, plazaCell: Collider, wareCell: Collider) {
  const S = 1024, H = WORLD.half;
  const c = document.createElement("canvas"); c.width = c.height = S;
  const g = c.getContext("2d")!;
  const px = (v: number) => ((v + H) / (H * 2)) * S;
  const pw = (w: number) => (w / (H * 2)) * S;
  // base sidewalk
  g.fillStyle = "#585d64"; g.fillRect(0, 0, S, S);
  // outskirts dark
  g.fillStyle = "#262a30";
  g.fillRect(0, 0, S, px(-138)); g.fillRect(0, px(138), S, S - px(138));
  g.fillRect(0, 0, px(-138), S); g.fillRect(px(138), 0, S - px(138), S);
  // block interiors
  const R = WORLD.roads, inset = WORLD.roadHalf + 2.5;
  for (let i = 0; i < R.length - 1; i++) for (let j = 0; j < R.length - 1; j++) {
    const x0 = R[i] + inset, x1 = R[i + 1] - inset, z0 = R[j] + inset, z1 = R[j + 1] - inset;
    let col = `rgb(${52 + ((i * 7 + j * 3) % 3) * 4},${56 + ((i * 3 + j) % 3) * 4},${62 + ((i + j * 5) % 3) * 4})`;
    const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    const inPark = cx > park.x0 && cx < park.x1 && cz > park.z0 && cz < park.z1;
    const inPlaza = cx > plazaCell.x0 && cx < plazaCell.x1 && cz > plazaCell.z0 && cz < plazaCell.z1;
    const inWare = cx > wareCell.x0 && cx < wareCell.x1 && cz > wareCell.z0 && cz < wareCell.z1;
    if (inPark) col = "#2f6b33";
    if (inPlaza) col = "#6a6d75";
    if (inWare) col = "#4d4436";
    g.fillStyle = col;
    g.fillRect(px(x0), px(z0), pw(x1 - x0), pw(z1 - z0));
  }
  // park paths
  g.fillStyle = "#7a715c";
  g.fillRect(px((park.x0 + park.x1) / 2 - 1.5), px(park.z0), pw(3), pw(park.z1 - park.z0));
  g.fillRect(px(park.x0), px((park.z0 + park.z1) / 2 - 1.5), pw(park.x1 - park.x0), pw(3));
  // docks wood
  g.fillStyle = "#5a4a33";
  g.fillRect(px(-24), px(134), pw(48), pw(20));
  // roads
  g.fillStyle = "#202329";
  for (const rc of R) {
    g.fillRect(px(-140), px(rc - WORLD.roadHalf), pw(280), pw(WORLD.roadHalf * 2));
    g.fillRect(px(rc - WORLD.roadHalf), px(-140), pw(WORLD.roadHalf * 2), pw(280));
  }
  // center dashes
  g.fillStyle = "#b89a3e";
  for (const rc of R) {
    for (let s = -136; s < 136; s += 8) {
      g.fillRect(px(s), px(rc - 0.25), pw(3.5), pw(0.5));
      g.fillRect(px(rc - 0.25), px(s), pw(0.5), pw(3.5));
    }
  }
  // crosswalks at a few intersections
  g.fillStyle = "rgba(220,220,220,.75)";
  const crosses: [number, number][] = [[0, 0], [-44, 44], [44, -44]];
  for (const [ix, iz] of crosses) {
    for (let k = -4; k <= 4; k += 2) {
      g.fillRect(px(ix + k - 0.5), px(iz + 6), pw(1), pw(3));
      g.fillRect(px(ix + 6), px(iz + k - 0.5), pw(3), pw(1));
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

export function buildCity(scene: THREE.Scene, quality: "low" | "high"): CityData {
  const group = new THREE.Group();
  scene.add(group);
  const colliders: Collider[] = [];
  const R = WORLD.roads;

  const park: Collider = { x0: 44 + 7.5, x1: 88 - 7.5, z0: 44 + 7.5, z1: 88 - 7.5 };
  const plazaCell: Collider = { x0: -88 + 7.5, x1: -44 - 7.5, z0: -88 + 7.5, z1: -44 - 7.5 };
  const wareCell: Collider = { x0: 44 + 7.5, x1: 88 - 7.5, z0: -88 + 7.5, z1: -44 - 7.5 };
  const plaza = { x: -66, z: -66 };
  const parkC = { x: 66, z: 66 };
  const warehouse = { x: 66, z: -66 };
  const docks = { x: 0, z: 142 };

  // ground
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(WORLD.ground, WORLD.ground),
    new THREE.MeshStandardMaterial({ map: groundTexture(park, plazaCell, wareCell), roughness: 0.95 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = quality === "high";
  group.add(ground);

  // water
  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(2000, 2000),
    new THREE.MeshStandardMaterial({ color: 0x0d2a44, roughness: 0.25, metalness: 0.6 })
  );
  water.rotation.x = -Math.PI / 2;
  water.position.y = -0.7;
  group.add(water);

  // buildings (instanced)
  const { mapT, emiT } = facadeTextures();
  const windowMat = new THREE.MeshStandardMaterial({
    map: mapT, emissiveMap: emiT, emissive: 0xffffff, emissiveIntensity: 0, roughness: 0.9,
  });
  interface B { x: number; z: number; w: number; d: number; h: number; color: THREE.Color }
  const list: B[] = [];
  const palette = [0xbfae94, 0x9aa0a8, 0xa8765e, 0x8b8f99, 0xc4b9a5, 0x7d8a99, 0xb0937a];
  for (let i = 0; i < R.length - 1; i++) for (let j = 0; j < R.length - 1; j++) {
    const isPark = i === 4 && j === 4, isPlaza = i === 1 && j === 1, isWare = i === 4 && j === 1;
    if (isPark || isPlaza || isWare) continue;
    const bx0 = R[i] + 8, bx1 = R[i + 1] - 8, bz0 = R[j] + 8, bz1 = R[j + 1] - 8;
    const mx = (bx0 + bx1) / 2, mz = (bz0 + bz1) / 2;
    const lots: [number, number][] = [
      [(bx0 + mx) / 2, (bz0 + mz) / 2], [(mx + bx1) / 2, (bz0 + mz) / 2],
      [(bx0 + mx) / 2, (mz + bz1) / 2], [(mx + bx1) / 2, (mz + bz1) / 2],
    ];
    for (const [lx, lz] of lots) {
      if (Math.random() < 0.12) continue;
      const w = rand(9, 12.5), d = rand(9, 12.5);
      const dc = Math.max(Math.abs(lx), Math.abs(lz));
      const h = dc < 55 ? rand(16, 42) : rand(7, 18);
      const x = lx + rand(-1, 1), z = lz + rand(-1, 1);
      list.push({ x, z, w, d, h, color: new THREE.Color(pick(palette)) });
      colliders.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2 });
    }
  }
  const bGeo = new THREE.BoxGeometry(1, 1, 1);
  const bInst = new THREE.InstancedMesh(bGeo, windowMat, list.length);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), sv = new THREE.Vector3(), pv = new THREE.Vector3();
  list.forEach((b, k) => {
    pv.set(b.x, b.h / 2, b.z); sv.set(b.w, b.h, b.d);
    m4.compose(pv, q, sv);
    bInst.setMatrixAt(k, m4);
    bInst.setColorAt(k, b.color);
  });
  bInst.instanceMatrix.needsUpdate = true;
  if (bInst.instanceColor) bInst.instanceColor.needsUpdate = true;
  bInst.castShadow = quality === "high";
  bInst.receiveShadow = true;
  group.add(bInst);

  // street lamps
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x22252a, roughness: 0.8 });
  const bulbMat = new THREE.MeshStandardMaterial({ color: 0x555550, emissive: 0xffd9a0, emissiveIntensity: 0, roughness: 0.4 });
  const lampPts: [number, number][] = [];
  for (const rc of R) {
    for (let s = -120; s <= 120; s += 26) {
      lampPts.push([s, rc + 7]); lampPts.push([rc - 7, s + 13]);
    }
  }
  const poleInst = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.09, 0.13, 6, 6), poleMat, lampPts.length);
  const bulbInst = new THREE.InstancedMesh(new THREE.SphereGeometry(0.24, 8, 6), bulbMat, lampPts.length);
  lampPts.forEach(([x, z], k) => {
    pv.set(x, 3, z); sv.set(1, 1, 1); m4.compose(pv, q, sv); poleInst.setMatrixAt(k, m4);
    pv.set(x, 6.1, z); m4.compose(pv, q, sv); bulbInst.setMatrixAt(k, m4);
  });
  poleInst.instanceMatrix.needsUpdate = true;
  bulbInst.instanceMatrix.needsUpdate = true;
  group.add(poleInst, bulbInst);

  // park trees
  const trunkI = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.18, 0.3, 2.4, 6), new THREE.MeshStandardMaterial({ color: 0x4a3320, roughness: 1 }), 26);
  const leafI = new THREE.InstancedMesh(new THREE.ConeGeometry(1.7, 3.6, 7), new THREE.MeshStandardMaterial({ color: 0x2c5c2e, roughness: 1 }), 26);
  for (let k = 0; k < 26; k++) {
    const x = rand(park.x0 + 2, park.x1 - 2), z = rand(park.z0 + 2, park.z1 - 2);
    pv.set(x, 1.2, z); sv.set(1, 1, 1); m4.compose(pv, q, sv); trunkI.setMatrixAt(k, m4);
    pv.set(x, 3.6, z); const s = rand(0.8, 1.3); sv.set(s, s, s); m4.compose(pv, q, sv); leafI.setMatrixAt(k, m4);
  }
  trunkI.instanceMatrix.needsUpdate = true;
  leafI.instanceMatrix.needsUpdate = true;
  trunkI.castShadow = quality === "high";
  group.add(trunkI, leafI);
  // pond
  const pond = new THREE.Mesh(new THREE.CircleGeometry(5, 20), new THREE.MeshStandardMaterial({ color: 0x1d4d6b, roughness: 0.2, metalness: 0.5 }));
  pond.rotation.x = -Math.PI / 2; pond.position.set(parkC.x - 8, 0.03, parkC.z + 6);
  group.add(pond);

  // plaza fountain
  const stone = new THREE.MeshStandardMaterial({ color: 0x8a8d94, roughness: 0.8 });
  const base = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.5, 1, 14), stone);
  base.position.set(plaza.x, 0.5, plaza.z); base.castShadow = true;
  const fw = new THREE.Mesh(new THREE.CircleGeometry(2.9, 18), new THREE.MeshStandardMaterial({ color: 0x2a6d8f, roughness: 0.15, metalness: 0.4 }));
  fw.rotation.x = -Math.PI / 2; fw.position.set(plaza.x, 1.02, plaza.z);
  const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.6, 2, 8), stone);
  pillar.position.set(plaza.x, 1.6, plaza.z);
  group.add(base, fw, pillar);
  colliders.push({ x0: plaza.x - 3.4, x1: plaza.x + 3.4, z0: plaza.z - 3.4, z1: plaza.z + 3.4 });

  // warehouse crates + containers
  const crateCols = [0x7a5c38, 0x6b5133, 0x5c6167, 0x71603c];
  for (let k = 0; k < 16; k++) {
    const s = rand(1.2, 2.2);
    const x = rand(wareCell.x0 + 2, wareCell.x1 - 2), z = rand(wareCell.z0 + 2, wareCell.z1 - 2);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), new THREE.MeshStandardMaterial({ color: pick(crateCols), roughness: 0.9 }));
    mesh.position.set(x, s / 2, z); mesh.rotation.y = rand(0, 0.6);
    mesh.castShadow = quality === "high";
    group.add(mesh);
    colliders.push({ x0: x - s / 2, x1: x + s / 2, z0: z - s / 2, z1: z + s / 2 });
  }
  const contCols = [0x8c2f2f, 0x2f5f8c];
  contCols.forEach((cc, i) => {
    const x = warehouse.x - 6 + i * 12, z = warehouse.z + 10;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(6, 2.6, 2.5), new THREE.MeshStandardMaterial({ color: cc, roughness: 0.7, metalness: 0.3 }));
    mesh.position.set(x, 1.3, z); mesh.castShadow = true;
    group.add(mesh);
    colliders.push({ x0: x - 3, x1: x + 3, z0: z - 1.25, z1: z + 1.25 });
  });

  // docks posts + crates + boat
  const wood = new THREE.MeshStandardMaterial({ color: 0x4a3a26, roughness: 1 });
  for (let k = 0; k < 6; k++) {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 2.4, 8), wood);
    p.position.set(-20 + k * 8, 0.4, 152);
    group.add(p);
  }
  for (let k = 0; k < 5; k++) {
    const s = rand(1.2, 1.8);
    const x = rand(-16, 16), z = rand(136, 146);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), new THREE.MeshStandardMaterial({ color: pick(crateCols), roughness: 0.9 }));
    mesh.position.set(x, s / 2, z);
    group.add(mesh);
    colliders.push({ x0: x - s / 2, x1: x + s / 2, z0: z - s / 2, z1: z + s / 2 });
  }
  const hull = new THREE.Mesh(new THREE.BoxGeometry(3, 1.4, 8), new THREE.MeshStandardMaterial({ color: 0x7a2e2e, roughness: 0.7 }));
  hull.position.set(34, -0.1, 178);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(2, 1.4, 2.4), new THREE.MeshStandardMaterial({ color: 0xd8d4c8, roughness: 0.7 }));
  cabin.position.set(34, 1.2, 177);
  group.add(hull, cabin);

  function roadPointNear(x: number, z: number, minD: number, maxD: number) {
    for (let t = 0; t < 14; t++) {
      const axis: "x" | "z" = Math.random() < 0.5 ? "x" : "z";
      const road = pick(R);
      const dir = (Math.random() < 0.5 ? 1 : -1) as 1 | -1;
      const s = rand(-128, 128);
      const lane = dir > 0 ? 2.4 : -2.4;
      const px2 = axis === "x" ? s : road + lane;
      const pz2 = axis === "x" ? road + lane : s;
      const d = Math.hypot(px2 - x, pz2 - z);
      if (d >= minD && d <= maxD) return { x: px2, z: pz2, axis, dir, road };
    }
    return { x: 0, z: 2.4, axis: "x" as const, dir: 1 as const, road: 0 };
  }
  function sidePointNear(x: number, z: number, minD: number, maxD: number) {
    for (let t = 0; t < 14; t++) {
      const axis: "x" | "z" = Math.random() < 0.5 ? "x" : "z";
      const road = pick(R);
      const s = rand(-128, 128);
      const side = (Math.random() < 0.5 ? 1 : -1) * rand(6.5, 9);
      const px2 = axis === "x" ? s : road + side;
      const pz2 = axis === "x" ? road + side : s;
      const d = Math.hypot(px2 - x, pz2 - z);
      if (d >= minD && d <= maxD) return { x: px2, z: pz2 };
    }
    return { x: x + 20, z };
  }

  return { group, colliders, windowMat, bulbMat, plaza, parkC, warehouse, docks, roadPointNear, sidePointNear };
}
