/* GTA-style procedural audio: engine, sirens, gunshots, jingles */
export class AudioSys {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  muted = false;
  private noiseBuf: AudioBuffer | null = null;
  private engOsc: OscillatorNode | null = null;
  private engOsc2: OscillatorNode | null = null;
  private engGain: GainNode | null = null;
  private engFilter: BiquadFilterNode | null = null;
  private skidSrc: AudioBufferSourceNode | null = null;
  private skidGain: GainNode | null = null;
  private sirOsc: OscillatorNode | null = null;
  private sirGain: GainNode | null = null;
  private sirHigh = false;
  private sirTimer: number | null = null;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.85;
    this.master.connect(this.ctx.destination);
    const len = this.ctx.sampleRate * 2;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const ctx = this.ctx;

    // engine loop
    this.engOsc = ctx.createOscillator(); this.engOsc.type = "sawtooth"; this.engOsc.frequency.value = 55;
    this.engOsc2 = ctx.createOscillator(); this.engOsc2.type = "square"; this.engOsc2.frequency.value = 28;
    this.engFilter = ctx.createBiquadFilter(); this.engFilter.type = "lowpass"; this.engFilter.frequency.value = 400;
    this.engGain = ctx.createGain(); this.engGain.gain.value = 0;
    this.engOsc.connect(this.engFilter); this.engOsc2.connect(this.engFilter);
    this.engFilter.connect(this.engGain); this.engGain.connect(this.master);
    this.engOsc.start(); this.engOsc2.start();

    // skid loop
    this.skidSrc = ctx.createBufferSource(); this.skidSrc.buffer = this.noiseBuf; this.skidSrc.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 950; bp.Q.value = 2;
    this.skidGain = ctx.createGain(); this.skidGain.gain.value = 0;
    this.skidSrc.connect(bp); bp.connect(this.skidGain); this.skidGain.connect(this.master);
    this.skidSrc.start();

    // siren loop
    this.sirOsc = ctx.createOscillator(); this.sirOsc.type = "triangle"; this.sirOsc.frequency.value = 700;
    this.sirGain = ctx.createGain(); this.sirGain.gain.value = 0;
    this.sirOsc.connect(this.sirGain); this.sirGain.connect(this.master);
    this.sirOsc.start();
    this.sirTimer = window.setInterval(() => {
      this.sirHigh = !this.sirHigh;
      if (this.sirOsc && this.ctx) this.sirOsc.frequency.setTargetAtTime(this.sirHigh ? 920 : 690, this.ctx.currentTime, 0.03);
    }, 430);
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.85, this.ctx.currentTime, 0.08);
  }

  /** per-frame continuous sounds */
  frame(engine: boolean, speed01: number, skid01: number, siren01: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    if (this.engGain && this.engOsc && this.engOsc2 && this.engFilter) {
      const r = 1 + speed01 * 2.4;
      this.engOsc.frequency.setTargetAtTime(52 * r, t, 0.06);
      this.engOsc2.frequency.setTargetAtTime(26 * r, t, 0.06);
      this.engFilter.frequency.setTargetAtTime(320 + speed01 * 1100, t, 0.06);
      this.engGain.gain.setTargetAtTime(engine ? 0.05 + speed01 * 0.05 : 0, t, 0.08);
    }
    if (this.skidGain) this.skidGain.gain.setTargetAtTime(Math.min(1, skid01) * 0.14, t, 0.05);
    if (this.sirGain) this.sirGain.gain.setTargetAtTime(Math.min(1, siren01) * 0.055, t, 0.2);
  }

  private noise(dur: number, filterType: BiquadFilterType, freq: number, vol: number, when = 0, rate = 1, q = 1) {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const ctx = this.ctx, t = ctx.currentTime + when;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf; src.playbackRate.value = rate;
    const f = ctx.createBiquadFilter(); f.type = filterType; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t, Math.random() * 1.5); src.stop(t + dur + 0.05);
  }

  private tone(f0: number, f1: number, dur: number, vol: number, type: OscillatorType = "sine", when = 0) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx, t = ctx.currentTime + when;
    const o = ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + dur + 0.05);
  }

  shot(kind: "pistol" | "uzi" | "shotgun" | "enemy") {
    if (kind === "pistol") { this.noise(0.14, "highpass", 900, 0.4); this.tone(320, 55, 0.16, 0.35, "square"); }
    else if (kind === "uzi") { this.noise(0.08, "highpass", 1400, 0.26); this.tone(420, 90, 0.08, 0.22, "square"); }
    else if (kind === "shotgun") { this.noise(0.4, "lowpass", 1400, 0.55, 0, 0.7); this.tone(150, 35, 0.4, 0.5, "sawtooth"); }
    else { this.noise(0.12, "highpass", 1100, 0.22); this.tone(300, 70, 0.12, 0.2, "square"); }
  }
  dry() { this.tone(1400, 900, 0.05, 0.12, "square"); }
  fist() { this.noise(0.09, "lowpass", 500, 0.32); this.tone(130, 45, 0.1, 0.3); }
  crash(v = 1) { this.noise(0.3, "lowpass", 700, 0.4 * v, 0, 0.8); this.tone(120, 40, 0.28, 0.4 * v, "sawtooth"); }
  thud() { this.noise(0.12, "lowpass", 350, 0.4); this.tone(110, 38, 0.14, 0.42); }
  explosion() {
    this.noise(1.6, "lowpass", 900, 0.65, 0, 0.5);
    this.tone(90, 24, 1.4, 0.6, "sine");
    this.noise(0.5, "highpass", 2000, 0.3);
  }
  horn() { this.tone(370, 365, 0.4, 0.14, "square"); this.tone(466, 460, 0.4, 0.12, "square"); }
  door() { this.noise(0.08, "lowpass", 600, 0.3); this.tone(90, 50, 0.1, 0.3); }
  pickup() { this.tone(660, 990, 0.12, 0.16); }
  money() { this.tone(880, 1320, 0.09, 0.16); this.tone(1100, 1560, 0.1, 0.14, "sine", 0.09); }
  uiClick() { this.tone(500, 500, 0.05, 0.1, "square"); }
  missionStart() { this.tone(392, 392, 0.14, 0.2, "square"); this.tone(587, 587, 0.2, 0.2, "square", 0.15); }
  pass() { [523, 659, 784, 1046].forEach((f, i) => this.tone(f, f, 0.16, 0.2, "square", i * 0.13)); }
  fail() { [330, 262, 196].forEach((f, i) => this.tone(f, f * 0.94, 0.2, 0.2, "sawtooth", i * 0.16)); }
  wasted() { this.tone(110, 50, 1.6, 0.4, "sawtooth"); this.tone(165, 70, 1.6, 0.25, "sawtooth", 0.1); }
  busted() { this.tone(440, 415, 0.3, 0.25, "square"); this.tone(415, 370, 0.5, 0.25, "square", 0.3); }
  checkpoint() { this.tone(784, 1175, 0.12, 0.18); }

  dispose() {
    if (this.sirTimer) clearInterval(this.sirTimer);
    try { this.ctx?.close(); } catch { /* noop */ }
    this.ctx = null;
  }
}
