import { useCallback, useEffect, useRef, useState } from "react";
import {
  Play, Pause, RotateCcw, Camera, Orbit, Tags, Moon, Sparkles,
  X, ChevronLeft, Gauge, CalendarDays, Rocket, MousePointer2,
  ZoomIn, Move3d, Telescope, RefreshCw, Info,
} from "lucide-react";
import { SolarEngine, BODIES, type BodyData } from "./game/solar";

const fa = (n: number | string) => Number(n).toLocaleString("fa-IR");
const sliderToSpeed = (v: number) => 0.25 * Math.pow(240, v / 100);
const fmtSpeed = (s: number) => (s < 10 ? fa(s.toFixed(1)) : fa(Math.round(s)));

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<SolarEngine | null>(null);

  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<BodyData | null>(null);
  const [playing, setPlaying] = useState(true);
  const [speedV, setSpeedV] = useState(30);
  const [days, setDays] = useState(0);
  const [tour, setTour] = useState(false);
  const [showOrbits, setShowOrbits] = useState(true);
  const [showLabels, setShowLabels] = useState(true);
  const [showMoons, setShowMoons] = useState(true);
  const [showBelt, setShowBelt] = useState(true);
  const [autoRot, setAutoRot] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);
  const tourIdx = useRef(0);

  useEffect(() => {
    if (!canvasRef.current || !labelRef.current) return;
    const engine = new SolarEngine(canvasRef.current, labelRef.current, {
      onSelect: (b) => {
        setSelected(b);
        setPanelOpen(!!b);
        if (b) {
          const i = BODIES.findIndex((x) => x.id === b.id);
          if (i >= 0) tourIdx.current = i;
        }
      },
      onStats: (d) => setDays(Math.floor(d)),
      onReady: () => setLoading(false),
    });
    engineRef.current = engine;
    engine.setSpeed(sliderToSpeed(30));
    engine.start();
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  /* tour mode */
  useEffect(() => {
    if (!tour) return;
    const t = setInterval(() => {
      tourIdx.current = (tourIdx.current + 1) % BODIES.length;
      engineRef.current?.select(BODIES[tourIdx.current].id, true);
    }, 9000);
    return () => clearInterval(t);
  }, [tour]);

  const pick = useCallback((id: string) => engineRef.current?.select(id, true), []);
  const closePanel = useCallback(() => {
    setPanelOpen(false);
    engineRef.current?.select(null, true);
  }, []);

  const togglePlay = () => {
    setPlaying((p) => {
      engineRef.current?.setPaused(p);
      return !p;
    });
  };
  const onSpeed = (v: number) => {
    setSpeedV(v);
    engineRef.current?.setSpeed(sliderToSpeed(v));
  };
  const shot = () => {
    const url = engineRef.current?.capture();
    if (!url) return;
    const a = document.createElement("a");
    a.href = url;
    a.download = "solar-system.png";
    a.click();
  };

  const speed = sliderToSpeed(speedV);
  const years = days / 365.25;

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#02030a] text-white">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      <div ref={labelRef} className="pointer-events-none absolute inset-0 z-10 overflow-hidden" />

      {/* ---------- loading ---------- */}
      {loading && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#02030a]">
          <div className="loader-orbit">
            <div className="loader-sun" />
            <div className="loader-p loader-p1" />
            <div className="loader-p loader-p2" />
            <div className="loader-p loader-p3" />
          </div>
          <h1 className="mt-8 text-2xl font-black tracking-wide">منظومه شمسی</h1>
          <p className="mt-2 animate-pulse text-sm text-slate-400">در حال ساخت سیارات...</p>
        </div>
      )}

      {/* ---------- header ---------- */}
      <header className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-2 p-3 md:p-5">
        <div className="glass pointer-events-auto rounded-2xl px-4 py-2.5">
          <h1 className="flex items-center gap-2 text-lg font-black leading-none md:text-2xl">
            <Telescope className="h-5 w-5 text-amber-300 md:h-6 md:w-6" />
            منظومه شمسی
          </h1>
          <p className="mt-1 text-[11px] text-slate-300 md:text-xs">سفری تعاملی میان ستاره و سیارات</p>
        </div>
        <div className="glass pointer-events-auto flex items-center gap-3 rounded-2xl px-4 py-2.5 text-xs md:text-sm">
          <span className="flex items-center gap-1.5 font-bold text-amber-200">
            <CalendarDays className="h-4 w-4" />
            روز {fa(days)}
          </span>
          <span className="hidden text-slate-300 sm:inline">({years < 1 ? `${fa(Math.round(days))} روز` : `${fa(years.toFixed(1))} سال`} سپری شده)</span>
          <span className="flex items-center gap-1.5 border-r border-white/15 pr-3 font-bold text-sky-300">
            <Gauge className="h-4 w-4" />
            <span dir="ltr">×{fmtSpeed(speed)}</span>
          </span>
        </div>
      </header>

      {/* ---------- planet nav (desktop) ---------- */}
      <nav className="absolute right-4 top-1/2 z-20 hidden w-44 -translate-y-1/2 flex-col gap-1.5 lg:flex">
        {BODIES.map((b) => (
          <button
            key={b.id}
            onClick={() => pick(b.id)}
            className={`glass group flex items-center gap-2.5 rounded-xl px-3 py-2 text-right text-sm transition-all hover:scale-[1.03] hover:bg-white/15 ${
              selected?.id === b.id ? "ring-2" : ""
            }`}
            style={selected?.id === b.id ? ({ "--tw-ring-color": b.color } as React.CSSProperties) : undefined}
          >
            <span className="h-3.5 w-3.5 shrink-0 rounded-full" style={{ background: b.color, boxShadow: `0 0 10px ${b.color}` }} />
            <span className="flex-1 font-bold">{b.nameFa}</span>
            <ChevronLeft className="h-3.5 w-3.5 text-slate-400 opacity-0 transition-opacity group-hover:opacity-100" />
          </button>
        ))}
      </nav>

      {/* ---------- planet chips (mobile/tablet) ---------- */}
      <div className="absolute inset-x-0 top-[76px] z-20 flex gap-2 overflow-x-auto px-3 pb-2 md:top-[92px] lg:hidden" dir="ltr">
        <div className="mx-auto flex gap-2" dir="rtl">
          {BODIES.map((b) => (
            <button
              key={b.id}
              onClick={() => pick(b.id)}
              className={`glass flex shrink-0 items-center gap-1.5 rounded-full py-1.5 pl-3 pr-2 text-xs font-bold transition-all ${
                selected?.id === b.id ? "scale-105 bg-white/20" : ""
              }`}
              style={selected?.id === b.id ? { boxShadow: `0 0 0 2px ${b.color}` } : undefined}
            >
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: b.color, boxShadow: `0 0 8px ${b.color}` }} />
              {b.nameFa}
            </button>
          ))}
        </div>
      </div>

      {/* ---------- info panel ---------- */}
      {selected && panelOpen && (
        <aside className="glass anim-rise absolute bottom-[132px] left-3 right-3 z-20 max-h-[38vh] overflow-y-auto rounded-2xl p-4 md:bottom-auto md:left-5 md:right-auto md:top-1/2 md:max-h-[70vh] md:w-[340px] md:-translate-y-1/2 md:p-5 scroll-thin">
          <button
            onClick={closePanel}
            className="absolute left-3 top-3 rounded-full bg-white/10 p-1.5 transition-colors hover:bg-white/25"
            aria-label="بستن"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-3">
            <span
              className="h-11 w-11 shrink-0 rounded-full"
              style={{ background: `radial-gradient(circle at 32% 30%, #ffffff88, transparent 45%), ${selected.color}`, boxShadow: `0 0 24px ${selected.color}` }}
            />
            <div>
              <h2 className="text-xl font-black leading-tight">{selected.nameFa}</h2>
              <p className="text-xs tracking-[.2em] text-slate-400" dir="ltr">{selected.nameEn}</p>
            </div>
          </div>
          <p className="mt-3 text-[13px] leading-7 text-slate-200">{selected.desc}</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {selected.tags.map((t) => (
              <span key={t} className="rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-bold text-amber-200">
                {t}
              </span>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-1.5">
            {selected.facts.map((f) => (
              <div key={f.label} className="rounded-xl bg-black/30 px-2.5 py-2">
                <div className="text-[10px] text-slate-400">{f.label}</div>
                <div className="mt-0.5 text-xs font-black leading-5">{f.value}</div>
              </div>
            ))}
          </div>
          {selected.moons.length > 0 && (
            <div className="mt-3">
              <div className="mb-1.5 flex items-center gap-1.5 text-xs font-bold text-slate-300">
                <Moon className="h-3.5 w-3.5" /> قمرهای نمایشی
              </div>
              <div className="flex flex-wrap gap-1.5">
                {selected.moons.map((m) => (
                  <span key={m.name} className="rounded-full border border-white/15 px-2.5 py-1 text-[11px] text-slate-200">
                    {m.name}
                  </span>
                ))}
              </div>
            </div>
          )}
          <button
            onClick={() => pick(selected.id)}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-amber-500 to-orange-600 px-4 py-2.5 text-sm font-black transition-transform hover:scale-[1.02]"
          >
            <Rocket className="h-4 w-4" /> پرواز نزدیک‌تر
          </button>
        </aside>
      )}

      {/* ---------- bottom control bar ---------- */}
      <div className="absolute inset-x-0 bottom-0 z-20 flex flex-col items-center gap-2 p-3 md:p-4">
        {/* speed */}
        <div className="glass flex w-full max-w-xl items-center gap-3 rounded-2xl px-4 py-2.5">
          <button
            onClick={togglePlay}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-600 shadow-lg shadow-orange-900/50 transition-transform hover:scale-105"
            aria-label={playing ? "توقف" : "پخش"}
          >
            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 translate-x-[1px]" />}
          </button>
          <div className="flex flex-1 flex-col gap-1">
            <div className="flex items-center justify-between text-[11px] text-slate-300">
              <span className="font-bold">سرعت گذر زمان</span>
              <span className="font-black text-amber-300" dir="ltr">×{fmtSpeed(speed)}</span>
            </div>
            <input
              type="range" min={0} max={100} value={speedV}
              onChange={(e) => onSpeed(Number(e.target.value))}
              className="sol-range w-full"
              dir="ltr"
            />
          </div>
        </div>
        {/* toggles */}
        <div className="glass flex max-w-full items-center gap-1.5 overflow-x-auto rounded-2xl px-2.5 py-2">
          <Toggle icon={<Orbit className="h-4 w-4" />} label="مدارها" on={showOrbits} onClick={() => { const v = !showOrbits; setShowOrbits(v); engineRef.current?.setOrbits(v); }} />
          <Toggle icon={<Tags className="h-4 w-4" />} label="نام‌ها" on={showLabels} onClick={() => { const v = !showLabels; setShowLabels(v); engineRef.current?.setLabels(v); }} />
          <Toggle icon={<Moon className="h-4 w-4" />} label="قمرها" on={showMoons} onClick={() => { const v = !showMoons; setShowMoons(v); engineRef.current?.setMoons(v); }} />
          <Toggle icon={<Sparkles className="h-4 w-4" />} label="سیارک‌ها" on={showBelt} onClick={() => { const v = !showBelt; setShowBelt(v); engineRef.current?.setBelt(v); }} />
          <Toggle icon={<RefreshCw className="h-4 w-4" />} label="چرخش دوربین" on={autoRot} onClick={() => { const v = !autoRot; setAutoRot(v); engineRef.current?.setAutoRotate(v); }} />
          <Toggle icon={<Rocket className="h-4 w-4" />} label="تور" on={tour} accent={tour} onClick={() => setTour((t) => !t)} />
          <button onClick={() => engineRef.current?.resetView()} className="flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 transition-colors hover:bg-white/10">
            <RotateCcw className="h-4 w-4" /> نمای کلی
          </button>
          <button onClick={shot} className="flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 transition-colors hover:bg-white/10">
            <Camera className="h-4 w-4" /> عکس
          </button>
        </div>
        {/* hint */}
        <div className="hidden items-center gap-4 text-[11px] text-slate-400 md:flex">
          <span className="flex items-center gap-1"><Move3d className="h-3.5 w-3.5" /> چرخش: درگ موس</span>
          <span className="flex items-center gap-1"><ZoomIn className="h-3.5 w-3.5" /> زوم: اسکرول</span>
          <span className="flex items-center gap-1"><MousePointer2 className="h-3.5 w-3.5" /> انتخاب: کلیک روی سیاره</span>
        </div>
      </div>

      {/* tour badge */}
      {tour && (
        <div className="glass anim-pulse-glow absolute bottom-[132px] right-3 z-20 flex items-center gap-2 rounded-full px-4 py-2 text-xs font-black text-amber-200 md:bottom-auto md:right-auto md:left-5 md:top-24">
          <Rocket className="h-4 w-4" />
          تور خودکار: {BODIES[tourIdx.current]?.nameFa}
          <button onClick={() => setTour(false)} className="rounded-full bg-white/10 p-1 hover:bg-white/25" aria-label="توقف تور">
            <X className="h-3 w-3" />
          </button>
        </div>
      )}

      {/* reopen panel button */}
      {selected && !panelOpen && (
        <button
          onClick={() => setPanelOpen(true)}
          className="glass absolute left-3 top-24 z-20 flex items-center gap-1.5 rounded-full px-3 py-2 text-xs font-bold md:left-5 md:top-28"
        >
          <Info className="h-4 w-4 text-amber-300" /> {selected.nameFa}
        </button>
      )}
    </div>
  );
}

function Toggle({ icon, label, on, onClick, accent }: {
  icon: React.ReactNode; label: string; on: boolean; onClick: () => void; accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition-all ${
        accent ? "bg-gradient-to-l from-amber-500 to-orange-600 text-white shadow-lg shadow-orange-900/40"
        : on ? "bg-white/15 text-white" : "text-slate-400 hover:bg-white/10 hover:text-slate-200"
      }`}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
      <span className={`h-1.5 w-1.5 rounded-full ${on || accent ? "bg-emerald-400" : "bg-slate-600"}`} />
    </button>
  );
}
